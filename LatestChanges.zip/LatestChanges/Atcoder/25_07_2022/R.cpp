#include <bits/stdc++.h>
using namespace std;
#define pb                push_back
#define ppb               pop_back
#define pf                push_front
#define ppf               pop_front
#define all(x)            (x).begin(),(x).end()
#define sz(x)             (int)((x).size())
#define int               long long
#define M                 1000000007
#define MM                998244353
#define fr                first
#define sc                second
#define pii               pair<int,int>
#define rep(i,a,b)        for(int i=a;i<b;i++)
#define mem1(a)           memset(a,-1,sizeof(a))
#define mem0(a)           memset(a,0,sizeof(a))
#define ppc               __builtin_popcount
 
template<typename T1,typename T2>
std::istream& operator>>(std::istream& in,pair<T1,T2> &a)
{
	in>>a.fr>>a.sc;
	return in;
}
template<typename T1,typename T2>
std::ostream& operator<<(std::ostream& out,pair<T1,T2> &a)
{
	out<<a.fr<<" "<<a.sc;
	return out;
}
 
/*
  prc(Matrix):    pre-calculates Matrix^(1<<i)
  mpw(int):       returns the power based on pre-calculation
  constructor:    Matrix <identifier>(vector<vector<int>>)
  * operator is overloaded for multiplication
  Matrix.mat[i][j] gives the element
*/
#define prc precalc_powers
#define mpw fast_exponentiation_with_precalc
const int MOD = 1e9 + 7;
const long long MOD2 = static_cast<long long>(MOD) * MOD;
const int MAX_K = 50;
 
struct Matrix
{
	vector< vector<int> > mat;
	int n_rows, n_cols;
 
	Matrix() {}
 
	Matrix(vector< vector<int> > values): mat(values), n_rows(values.size()),
		n_cols(values[0].size()) {}
 
	static Matrix identity_matrix(int n)
	{
		vector< vector<int> > values(n, vector<int>(n, 0));
		for(int i = 0; i < n; i++)
			values[i][i] = 1;
		return values;
	}
 
	Matrix operator*(const Matrix &other) const 
	{
		int n = n_rows, m = other.n_cols;
		vector< vector<int> > result(n_rows, vector<int>(n_cols, 0));
		for(int i = 0; i < n; i++)
			for(int j = 0; j < m; j++) {
				long long tmp = 0;
				for(int k = 0; k < n_cols; k++) {
					tmp += mat[i][k] * 1ll * other.mat[k][j];
					while(tmp >= MOD2)
						tmp -= MOD2;
				}
				result[i][j] = tmp % MOD;
			}
 
		return move(Matrix(move(result)));
	}
 
	inline bool is_square() const
	{
		return n_rows == n_cols;
	}
};
 
// M_powers[i] is M, raised to 2^i-th power
Matrix M_powers[61];
 
void precalc_powers(Matrix MT)
{
	assert(MT.is_square());
	M_powers[0] = MT;
 
	for(int i = 1; i < 61; i++)
		M_powers[i] = M_powers[i - 1] * M_powers[i - 1];
}
 
Matrix fast_exponentiation_with_precalc(int power)
{
	Matrix result = Matrix::identity_matrix(M_powers[0].mat.size());
	int pointer = 0;
	while(power) {
		if(power & 1)
			result = result * M_powers[pointer];
		pointer++;
		power >>= 1;
	}
	return result;
}
 
void solve(){
	int n,k;
	cin>>n>>k;
	vector<vector<int>> v(n);
	rep(i,0,n){
		rep(j,0,n){
			int x;
			cin>>x;
			v[i].pb(x);
		}
	}
	Matrix m(v);
	prc(m);
	Matrix res=mpw(k);
	int ans=0;
	rep(i,0,n){
		rep(j,0,n){
			ans+=res.mat[i][j];
			ans%=M;
		}
	}
	cout<<ans;
}
signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	#ifdef SEIVE
		seive();
	#endif
	#ifdef NCR
		init();
	#endif
	#ifdef DSU
		cleardsu(MAXDSUSIZE);
	#endif
	int t=1;
	//cin>>t;
	while(t--) solve();
	return 0;
}