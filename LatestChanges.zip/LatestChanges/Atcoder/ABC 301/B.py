n = 64
ans = 0
arr = list(map(int,input().split()))
for i in range(n):
    ans+=pow(2,i)*arr[i]
print(ans)
