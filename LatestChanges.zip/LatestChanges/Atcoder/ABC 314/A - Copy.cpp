#include <string>
#include <iostream>
#include <vector>
#include <utility>
#include <optional>
int main() {
    using namespace std;
    int N;
    string S;
    cin >> N >> S;
    vector<pair<int, char>> status(N); // Individual operation (last update time, current character)
    for (int i = 0; i < N; ++i)
        status[i] = {0, S[i]}; // Time 0 at first
    int Q;
    cin >> Q;
    optional<pair<int, int>> fill = nullopt; // Global operation (last update time, kind of last update)
    for (int i = 0; i < Q; ++i) { // Operation at time i
        int t, x;
        char c;
        cin >> t >> x >> c;
        if (t == 1) // individual operation
            status[x - 1] = {i, c};
        else // global operation
            fill = {i, t};
            
        // cout<<fill->first<<"=fill="<<fill->second<<endl;
    }
     for (const auto&[time, c] : status)
         if (!fill || time >= fill->first) // If global operation is absent or last update is later,
             cout << c; // print it directly
         else if (fill->second == 2) // otherwise, depending on the kind of the global operation,
             cout << static_cast<char>(tolower(c)); // make it lower
         else
             cout << static_cast<char>(toupper(c)); // or upper
     cout << endl;
    return 0;
}