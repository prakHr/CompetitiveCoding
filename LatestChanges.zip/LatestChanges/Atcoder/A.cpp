#include <bits/stdc++.h>
#define FAST_IO ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define int long long
#define pb push_back
#define eb emplace_back
#define mp make_pair
#define mt make_tuple
#define PI acos(-1)
#define sqr(a) ((a)*(a))
#define ff first
#define ss second
#define sf scanf
#define pf printf
#define pf1(a) pf("%lld", a);
#define pf2(a,b) pf("%lld %lld", a, b)
#define pf3(a,b,c) pf("%lld %lld %lld", a, b, c)
#define sf1(a) sf("%lld", &a)
#define sf2(a,b) sf("%lld %lld", &a, &b)
#define sf3(a,b,c) sf("%lld %lld %lld", &a, &b, &c)
#define sf4(a,b,c,d) sf("%lld %lld %lld %lld", &a, &b, &c, &d)
#define sf5(a,b,c,d,e) sf("%lld %lld %lld %lld %lld", &a, &b, &c, &d, &e)
#define sfc(a) sf(" %c", &a)
#define sfd(n) sf("%lf", &n)
#define FOR(i, j, k, in) for (int i=j ; i<k ; i+=in)
#define RFOR(i, j, k, in) for (int i=j ; i>=k ; i-=in)
#define REP(i, j) FOR(i, 0, j, 1)
#define RREP(i, j) RFOR(i, j, 0, 1)
#define FOREACH(it, l) for (auto it = l.begin(); it != l.end(); it++)
#define RESET(a, b) memset(a, (b), sizeof(a))
#define lb lower_bound
#define ub upper_bound
#define nl pf("\n")
#define endl '\n'
#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define SZ(v) (int)v.size()
#define ALL(v) v.begin(), v.end()
#define RSORT(v) sort(v.rbegin(),v.rend())
#define SORT(v) sort(ALL(v))
#define REVERSE(v) reverse(ALL(v))
#define UNIQUE(v) (v).erase(unique((v).begin(), (v).end()), (v).end())
#define on(n,i) (n|=(1LL<<i))
#define isOn(n,i) (n&(1LL<<i))
#define off(n,i) (n = isOn(n,i) ? n ^ (1LL<<i) : n)
#define gcd(a,b) __gcd(a,b)
#define lcm(a,b) (a/gcd(a,b)*b)
#define watch(a) cout << (#a) << " is " << (a) << '\n'
#define watch2(a,b) cout << (#a) << " is " << (a) << " and " << (#b) << " is " << (b) << '\n'
#define MIN3(a,b,c) MIN(a, MIN(b,c))
#define MAX3(a,b,c) MAX(a, MAX(b,c))
#define mem1(a) memset(a,-1,sizeof(a))
#define mem0(a) memset(a,0,sizeof(a))
#define ppc __builtin_popcount
#define pcnt(x) __builtin_popcount(x)
 
using namespace std;
using I = int;
using V = void;
typedef long long ll; 
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<string> vs;
typedef vector<pii> vii;
typedef vector<vi> vvi;
typedef map<int,int> mpii;
typedef set<int> seti;
typedef multiset<int> mseti;
typedef tuple<int,int,int> State;
 
template <class T>  inline void chmax(T &x,T &y) {if(x < y) swap(x,y);}
template <class T>  inline void chmin(T &x,T &y) {if(x > y) swap(x,y);}
/*----------------------Graph Moves----------------*/
//const int fx[]={-1,-1,+0,+0,+1,+1};
//const int fy[]={-1,+0,-1,+1,+0,+1};
//const int fx[]={+0,+0,+1,-1,-1,+1,-1,+1};   // Kings Move
//const int fy[]={-1,+1,+0,+0,+1,+1,-1,-1};  // Kings Move
//const int fx[]={-2, -2, -1, -1,  1,  1,  2,  2};  // Knights Move
//const int fy[]={-1,  1, -2,  2, -2,  2, -1,  1}; // Knights Move
/*------------------------------------------------*/
 
const int INF = 0x3f3f3f3f3f3f;
const int MOD2 = 1e9 + 7;
const int MOD = 998244353;
const double EPS = 10e-10;

const ll P2LIM=(ll)2e18;

const long long N = 3e5 + 10;
std::vector<std::string> transpose(const std::vector<std::string>& input) {
    if (input.empty()) return {};

    size_t numRows = input.size();
    size_t numCols = input[0].size();

    // Initialize the transposed vector with the appropriate size
    std::vector<std::string> transposed(numCols, std::string(numRows, ' '));

    // Transpose the elements
    for (size_t i = 0; i < numRows; ++i) {
        for (size_t j = 0; j < numCols; ++j) {
            transposed[j][i] = input[i][j];
        }
    }

    return transposed;
}
int zone(string S,string T,int N) {
        bitset<14> spat, tpat;
        REP(i, N) {
            if (S[i] == 'B') spat.set(i);
            if (T[i] == 'B') tpat.set(i);
        }
        if (spat.count() != tpat.count()) return -1;

        auto s = S;
        auto t = T;
        s.push_back('.');
        s.push_back('.');
        t.push_back('.');
        t.push_back('.');

        map<string, int> m;
        m[s] = 0;
        queue<tuple<string, int>> q;
        q.push({s, 0});
        while (!q.empty()) {
            auto [to, cost] = q.front();
            q.pop();
            if (m[to] != cost) continue;
            int ei = 0;
            REP(i, to.size()) {
                if (to[i] == '.') {
                    ei = i;
                    break;
                }
            }
            REP(i, to.size() - 1) {
                if (to[i] == '.') continue;
                if (to[i + 1] == '.') continue;
                auto ns = to;
                ns[ei] = to[i];
                ns[ei + 1] = to[i + 1];
                ns[i] = '.';
                ns[i + 1] = '.';
                if (m.count(ns)) continue;
                m[ns] = cost + 1;
                q.push({ns, cost + 1});
            }
        }
        if (m.count(t)) return m[t];
        return -1;
}
void Solution2(){
	//https://atcoder.jp/contests/abc361/tasks/abc361_d
	int N;
	string S,T;
	cin>>N>>S>>T;
	int ans = zone(S,T,N);
    cout<<ans<<endl;
}
int intersects(int l1, int r1, int l2, int r2){
	 return (l1 <= r2 && l2 <= r1);
}
void Solution(){

	
}
		
void SolutionABC362C(){
	int n;
    cin >> n;
    vi l(n), r(n);
    for (int i = 0; i < n; i++) {
        cin >> l[i] >> r[i];
    }
    int L = accumulate(l.begin(), l.end(), 0ll);
    int R = accumulate(r.begin(), r.end(), 0ll);
    if (R < 0ll || L > 0ll) cout << "No\n";
    else{
    	cout<<"Yes\n";
    	int p,sum;
    	p = -L,sum = 0ll;
    	REP(i,n){
    		cout<<l[i]+min(r[i]-l[i],p)<<" \n"[i==n-1];
    		sum += l[i]+min(r[i]-l[i],p);
    		p-=min(r[i]-l[i],p);
		}
		assert(sum==0ll);
	}
	
}
		
void SolutionABC362D(){
	int n,m;
    cin>>n>>m;
    int wa[n];
    vector<vi> a(n);
    map<pii, int> b;
    REP(i,n) cin>>wa[i];
    REP(i,m){
    	int x,y,w;
    	cin>>x>>y>>w;
    	x--,y--;
    	a[x].pb(y);
    	a[y].pb(x);
    	b[{x,y}] = w;
    	b[{y,x}] = w;
	}
	priority_queue<pii,vector<pii>, greater<pii>> pq;
    pq.push({wa[0], 0});
    int vis[n]={};
    int ww[n];
    while(!pq.empty()){
    	pii z = pq.top();
    	pq.pop();
    	int i,w;
    	i = z.ss,w = z.ff;
    	if(vis[i])continue;
    	vis[i] = 1;
    	ww[i] = w;
    	for(auto j:a[i]){
    		if(vis[j])continue;
    		pq.push({w+wa[j]+b[{i,j}],j});
		}
	}
	FOR(i,1,n,1)cout<<ww[i]<<" \n"[i+1==n];
}
const int MOD362E=998244353;
void SolutionABC362E(){
	int n;
	cin>>n;vi a(n);
	REP(i,n)cin>>a[i];
	cout<<n<<" ";
	int dp[n][n][n+1];
	REP(i,n)REP(j,n)REP(k,n+1)dp[i][j][k] = 0;
	REP(i,n)FOR(j,i+1,n,1){
		int d = a[j]-a[i];
		dp[i][j][2] = 1;
		FOR(k,j+1,n,1){
			int d2= a[k]-a[j];
			if(d!=d2)continue;
			FOR(l,3,n+1,1){
				dp[j][k][l]+=dp[i][j][l-1];
				dp[j][k][l]%=MOD362E;
			}	
		}
	}
		
	
	FOR(k,2,n+1,1){
		int ans = 0;
		REP(i,n)REP(j,n)
			ans=(ans+dp[i][j][k])%MOD362E;
		cout<<ans%MOD362E<<" ";
	}
	cout<<endl;
}

class suffixarray {
  public :
  int n;
  vector<int> p , c;
  string s;
  suffixarray(string &ss){
    s = ss;
    s += '$';
    n = s.size();
    int alphabet = 256;
    p.resize(n) , c.resize(n);
    vector<int> cnt(max(alphabet, n), 0);
    for (int i = 0; i < n; i++)
      cnt[s[i]]++;
    for (int i = 1; i < alphabet; i++)
      cnt[i] += cnt[i-1];
    for (int i = 0; i < n; i++)
      p[--cnt[s[i]]] = i;
    c[p[0]] = 0;
    int classes = 1;
    for (int i = 1; i < n; i++) {
      if (s[p[i]] != s[p[i-1]])
        classes++;
      c[p[i]] = classes - 1;
    }
    vector<int> pn(n), cn(n);
    for (int h = 0; (1 << h) < n; ++h) {
      for (int i = 0; i < n; i++) {
        pn[i] = p[i] - (1 << h);
        if (pn[i] < 0)
          pn[i] += n;
      }
      fill(cnt.begin(), cnt.begin() + classes, 0);
      for (int i = 0; i < n; i++)
        cnt[c[pn[i]]]++;
      for (int i = 1; i < classes; i++)
        cnt[i] += cnt[i-1];
      for (int i = n-1; i >= 0; i--)
        p[--cnt[c[pn[i]]]] = pn[i];
      cn[p[0]] = 0;
      classes = 1;
      for (int i = 1; i < n; i++) {
        pair<int, int> cur = {c[p[i]], c[(p[i] + (1 << h)) % n]};
        pair<int, int> prev = {c[p[i-1]], c[(p[i-1] + (1 << h)) % n]};
        if (cur != prev)
          ++classes;
        cn[p[i]] = classes - 1;
      }
      c.swap(cn);
    }
  }
  int lowerbound(string &t){
    int l = 1 , r = n - 1 , ans = n;
    while(l <= r){
      int mid = l + (r - l)/2;
      bool big = true;
      for(int i = p[mid] , j = 0 ; i < n and j < t.size() ; i++ , j++){
        if(s[i] < t[j]){
          big = false;
          break;
        } else if(s[i] > t[j]){
          break;
        }
      }
      if(big){
        ans = min(ans , mid);
        r = mid - 1;
      } 
      else {
        l = mid + 1;
      }
    }
    return ans;
  }
  int upperbound(string &t){
    int l = 1 , r = n - 1 , ans = n;
    while(l <= r){
      int mid = l + (r - l)/2 , cnt = 0;
      bool big = true;
      for(int i = p[mid] , j = 0 ; i < n and j < t.size() ; i++ , j++){
        if(s[i] < t[j]){
          big = false;
          break;
        } else if(s[i] > t[j]){
          break;
        }
        cnt++;
      }
      if(cnt == t.size()) big = false;
      if(big) {
        ans = min(ans , mid);
        r = mid - 1;
      }
      else{
        l = mid + 1;
      }
    }
    return ans;
  }
};
void SolutionABC362G(){
	int q;
	string s,t;
	cin>>s>>q;
	suffixarray sa(s);
	while(q--){
		cin>>t;
		int l =sa.lowerbound(t);
		int r = sa.upperbound(t);
		cout<<r-l<<endl;
	}
}
int32_t main() {
    FAST_IO;
    int tc=1;
//	cin>>tc;
	
    FOR(tn,1,tc+1,1) {
        
        SolutionABC362G();  
	}

 
    return 0;
}


