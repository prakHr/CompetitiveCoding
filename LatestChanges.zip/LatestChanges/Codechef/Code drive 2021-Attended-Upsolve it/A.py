tests=int(input())
for t in range(tests):
    n=int(input())
    arr=list(map(int,input().split()))

    
