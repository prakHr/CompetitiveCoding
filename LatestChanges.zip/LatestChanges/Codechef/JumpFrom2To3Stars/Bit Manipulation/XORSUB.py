from itertools import combinations_with_replacement
def powerset(s):
    x = len(s)
    ans = []
    for i in range(1 << x):
        ans.append([s[j] for j in range(x) if (i & (1 << j))])
    return ans
#print(powerset([1,2,3]))

#alists = [[1,2,3],[1,2,4],[1,2,5],[2,2,2],[3,3,3],[4,4,4],[2,2,3],[]]
#alists=[[None]*3 for i in range(3)]
comb = combinations_with_replacement([2,5,6], 3)
alists =[]
for i in list(comb):
    alists.append(list(i))

P = 4

for alist in alists:
    ans = []
    for p in powerset(alist):
        x=0
        for i in range(len(p)):
            x^=p[i]
        x = x^P     
        #print(p,x)
        ans.append([x,p])
    ans = sorted(ans,key=lambda student: student[0])
    
    print(alist,ans[-1])

