for i in range(1,100):
    n = i
    # n =1 1 to 9
    # n=2 10 to 99
    # n=3 100 to 999

    # 3,15,105,1005,10005,...
    ans=[]
    for j in range(pow(10,n-1),pow(10,n)):
        if j%2!=0 and j%3 ==0 and j%9!=0:
            ans.append(j)
    print(ans)
