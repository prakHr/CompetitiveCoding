#include <bits/stdc++.h>
#define ll long long
using namespace std;
vector<int> offersReceivedFrom(vector<int>in)
{
    vector<int> sol;
    int n = in.size();
    for(int i = 0; i < n; i++)
    {
        if(in[i] == 1)
            sol.push_back(i);
    }
    return sol;
}

int maximumOffer(vector<int> offeredSalary, vector<int> maxJobOffer, int minSalary, vector<int> companyHired, vector<int> companyOffered)
{
    int sol = -1,  k= companyOffered.size();
    int gotSalary = -1;
    for(int i = 0; i < k; i++)
    {
        int t = companyOffered[i];
        if(maxJobOffer[t] > companyHired[t] && offeredSalary[t] >= minSalary && offeredSalary[t] > gotSalary)
        {
            gotSalary = offeredSalary[t];
            sol = t;
        }
        
    }
    return sol;
}
int main() {
	ll t;
	std::ios_base::sync_with_stdio(false);
	cout.tie(NULL);
	cin.tie(NULL);
	cin>>t;
	while(t--)
	{
	    int n, m;
	    cin>>n>>m;
	    vector<int> minSalary(n);
	    for(int i = 0; i < n; i++)
	        cin>>minSalary[i];
	   
	    vector<int> offeredSalary(m), maxJobOffer(m);
	    for(int i = 0; i < m; i++)
	        cin>>offeredSalary[i]>>maxJobOffer[i];
	        
	    vector<vector<int> > qual(n, vector<int> (m));
	    for(int i = 0; i < n; i++)
	    {
	        string s;
	        cin>>s;
	       for(int j = 0; j < m; j++)
	            qual[i][j] = s[j] - '0';
	       
	    }
	   long long hiredCandidate = 0, totalSalary = 0;
	   vector<int> companyHired(m);
	   for(int i = 0; i < m; i++)
	        companyHired[i] = 0;
	   
	   for(int i = 0; i < n; i++)
	   {
	       vector<int> companyOffered = offersReceivedFrom(qual[i]);
	       int maxOffer = maximumOffer(offeredSalary, maxJobOffer, minSalary[i], companyHired, companyOffered);
	       if(maxOffer != -1)
	       {
	           hiredCandidate++;
	           totalSalary += offeredSalary[maxOffer];
	           companyHired[maxOffer] ++;
	       }
	   }
	   int companyNotHired = 0;
	   for(int i = 0; i < m; i++)
	   {
	       if(companyHired[i] == 0) companyNotHired++;
	   }
	   cout<<hiredCandidate<<" "<<totalSalary<<" "<<companyNotHired<<endl;
	}
	return 0;
}