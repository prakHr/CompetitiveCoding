#include <bits/stdc++.h>
using namespace std;
vector<bool>sieveArr(1000000, false); 
void sieveConstruct(long long int limit)
{
    sieveArr[2] = true; 
    for(int i=4; i<=limit; i+=2)
        sieveArr[i] = false;
    for(int i=3; i*i<=limit; i+=2)
    {
        sieveArr[i] = true; 
        for(int j=i*2; j<=limit; j+=i)
            sieveArr[j] = false;
    }
}
bool prime(long long int n)
{
    for(int i=2; i<=sqrt(n); )
    {
        if(n % i == 0)
            return false;
        if(i==2)
            i++; 
        else
            i+=2;
    }
    if(n == 1 or n==0)
        return false;
    return true;
}
int main() {
   
	// your code goes here
	int t;
	cin >> t;
	while(t--)
	{
	    string s; 
	    cin >> s; 
	    int l = s.length(); 
	    string copy = s; 
	    bool done = false;
	    //s = "???31?"
	    for(int j=0; j<l; j++)
	    {
	        if(s[j] == '?')
	            copy[j] = '1'; 
	    }
	    //copy = "111311"
	    for(int i=0; i<l; i++)
	    {
	        if(s[i] == '?')
	        {
	            char start = (i == 0) ? '1' : '0'; 
	            for(char num = start; num <= '9' ; num++)
	            {
	                copy[i] = num; //111311, 211311,311311,411311,511311, ... 91131
	                long long int newNum = stol(copy); 
	                if(prime(newNum))
	                {
	                    done = true; 
	                    cout << newNum << endl; 
	                    break;
	                }
	                copy[i] = '1';
	            }
	        }
	        if(done)
	            break;
	    }
	 
	   
	}
	
	return 0;
}