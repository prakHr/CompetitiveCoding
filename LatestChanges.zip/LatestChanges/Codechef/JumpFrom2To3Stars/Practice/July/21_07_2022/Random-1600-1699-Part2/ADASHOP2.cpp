#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define ff first
#define ss second

void Solution(){
	int r,c;
	cin>>r>>c;
	vector<pair<int,int>> ans={{8,8},{7,7},{8,6},{3,1},{1,3},{6,8},{5,7},{8,4},{5,1},{1,5},{4,8},{3,7},{2,8},{1,7},{7,1},{8,2}};
	vector<pair<int,int>> before;
	if(r!=c){
		int d = (r+c)/2;
		before.pb({d,d});
		r=d;
		c=d;
	}
	if(r==c)before.pb({1,1});
	cout<<ans.size()+before.size()<<endl;
	for(auto u:before){
		cout<<u.ff<<" "<<u.ss<<endl;
	}
	for(auto u:ans){
		cout<<u.ff<<" "<<u.ss<<endl;
	}
}
int main() {
   
	// your code goes here
	int t;
	cin >> t;
	while(t--)
	{
	   Solution();
	}
	
	return 0;
}