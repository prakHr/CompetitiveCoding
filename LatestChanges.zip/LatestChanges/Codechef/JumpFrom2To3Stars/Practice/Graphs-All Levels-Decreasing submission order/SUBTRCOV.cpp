#include <bits/stdc++.h>

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;

using namespace std;

// #define endl '\n'
#define int long long int
#define rep(i, a, b) for (int i = a; i < b; i++)
#define revrep(i, a, b) for (int i = a; i >= b; i--)
#define pb push_back
#define pii pair<int, int>
#define vi vector<int>
#define vii vector<pii>
#define min3(a, b, c) min(a, min(b, c))
#define max3(a, b, c) max(a, max(b, c))
#define upb(vec, val) upper_bound((vec).begin(), (vec).end(), (val)) - (vec).begin()


template <typename T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template <typename T>
using ordered_multiset = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>;


ostream &operator<<( ostream &output, const pii &p ) { output << p.first << " " << p.second;return output; }
istream &operator>>( istream &input, pii &p ) { input >> p.first >> p.second;return input; }
template<typename T>
void inline println(vector<T> args){ for(T i: args)cout<<i<<" ";cout<<endl; }
void amax(int& a, int b) { a = max(a, b); }
void amin(int& a, int b) { a = min(a, b); }
int ceilInt(int a, int b) {
    if(!b) return 0;
    if(a%b) return a/b + 1;
    return a/b;
}

int INF = 1e18;
int MOD = 1e9+7;

vector<vi> adj, parent;
vi h, depth;
vii order, inout;
int n, t;

void dfs(int v, int p) {
    inout[v].first = t++;
    parent[v][0] = p;
    depth[v] = 0;
    for(int i: adj[v]) {
        if(i == p) continue;
        h[i] = h[v]+1;
        dfs(i, v);
        amax(depth[v], depth[i]+1);
    }
    sort(adj[v].rbegin(), adj[v].rend(), [&](int i, int j) {
        return depth[i] < depth[j];
    });
    inout[v].second = t++;
}

void processParent() {
    rep(j, 1, 20) {
        rep(i, 0, n) {
            int p = parent[i][j-1];
            if(p != -1) 
                parent[i][j] = parent[p][j-1];
            else 
                parent[i][j] = p;
        }
    }
}

bool isAncestor(int p, int v) {
    return inout[p].first <= inout[v].first && inout[v].second <= inout[p].second;
}

int findLCA(int a, int b) {
    if(isAncestor(a, b)) return a;
    if(isAncestor(b, a)) return b;
    for(int i=19; i>=0; i--) {
        int p = parent[a][i];
        if(p != -1 && !isAncestor(p, b))
            a = p;
    }
    return parent[a][0];
}

void findOrder(int v, int p) {
    for(int i: adj[v]) {
        if(i == p) continue;
        findOrder(i, v);
    }
    if(adj[v].size() == 1 && p != -1) {
        int lst = order.back().second;
        int lca = findLCA(v, lst);
        int pathLen = abs(h[lca]-h[v]);
        order.pb({pathLen, v});
    }
}

int diameterDfs() {
    dfs(0, -1);
    int mx = *max_element(h.begin(), h.end());
    rep(i, 0, n) {
        if(h[i] == mx) {
            return i;
        }
    }
    return -1;
}



void solve()
{   
    int k; cin>>n>>k;
    t = 0;
    inout.clear(), inout.resize(n);
    adj.clear(), adj.resize(n);
    h.clear(), h.resize(n, 0);
    depth.clear(), depth.resize(n, 0);
    parent.clear(), parent.resize(n, vi(20, 0));
    order.clear();
    rep(i, 0, n-1) {
        int a, b; cin>>a>>b;
        a--, b--;
        adj[a].pb(b);
        adj[b].pb(a);
    }
    int root = diameterDfs();
    h.assign(n, 0);
    depth.assign(n, 0);
    order.pb({1, root});
    t = 0;
    dfs(root, -1);
    processParent();
    findOrder(root, -1);
    int ans = 1; k--;
    order.erase(order.begin());
    sort(order.rbegin(), order.rend());
    rep(i, 0, n) {
        if(k <= 0) break;
        k -= order[i].first;
        ans++;
    }
    cout<<ans<<endl;
}



signed main()
{

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
#ifndef ONLINE_JUDGE
    // for getting input from input.txt
    freopen("input.txt", "r", stdin);
    // for writing output to output.txt
    freopen("output.txt", "w", stdout);
#endif

    int t = 1;
    cin>>t;
    rep(i, 0, t)
    {   
        // cout<<"Case #"<<i+1<<": ";
        solve();
    }
    return 0;
}