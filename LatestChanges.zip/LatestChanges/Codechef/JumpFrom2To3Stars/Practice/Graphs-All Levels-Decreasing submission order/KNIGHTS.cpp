#include<bits/stdc++.h>
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
#define rep(i,a,b) for(ll i=(a);i<=(b);++i)
#define per(i,a,b) for(ll i=(a);i>=(b);--i) 
#define pii pair<ll,ll>
using namespace std;
const ll N=205;
ll read(){
    ll x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
void write(ll a){
	if(a<0)putchar('-'),a=-a;
    if(a>9)write(a/10);
    putchar((a%10)|48);   
}
ll T,n,m,c[N*N],vis[N*N],tot,tot2,id[N][N];
char ch[N][N];
ll dx[8]={-2,-2,-1,-1,1,1,2,2};
ll dy[8]={-1,1,-2,2,-2,2,-1,1};
vector<ll>to[N*N];
void add(ll x,ll y){to[x].push_back(y);}
ll hungary(ll x){
	for(ll y:to[x]){
		if(!vis[y]){
			vis[y]=1;
			if(!c[y]||hungary(c[y]))return c[y]=x,1;
		}
	}
	return 0;
}
int main(){
	T=read();
	while(T--){
		n=read(),m=read();
		rep(i,1,n){
			rep(j,1,m)cin>>ch[i][j];
		}
		memset(vis,0,sizeof(vis));
		memset(c,0,sizeof(c));
		rep(i,0,n*m)to[i].clear();
		tot=tot2=0;
		rep(i,1,n){
			rep(j,1,m){
				if(((i+j)&1)){
					if(ch[i][j]=='.')id[i][j]=++tot;
				}
			}
		}
		rep(i,1,n){
			rep(j,1,m){
				if(!((i+j)&1)){
					if(ch[i][j]=='.')id[i][j]=++tot2;
				}
			}
		}
		rep(i,1,n){
			rep(j,1,m){
				if(ch[i][j]=='.'&&((i+j)&1)){
					rep(k,0,7){
						ll nx=i+dx[k],ny=j+dy[k];
						if(nx>=1&&nx<=n&&ny>=1&&ny<=m){
							if(ch[nx][ny]=='.')add(id[i][j],id[nx][ny]);
						}
					}
				}
			}
		}
		ll ans=0;
		rep(i,1,tot){
			memset(vis,0,sizeof(vis));
			ans+=hungary(i);
		}
		write(tot+tot2-ans),putchar('\n');
	}
	return 0;
}