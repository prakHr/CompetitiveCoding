#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;
#define IO ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
#define pb                          push_back
#define all(x)                      (x).begin(),(x).end()
#define ll                          long long
#define ull                         unsigned long long
#define ld                          long double
#define eps                         1e-9
#define sz(a)                       (ll)(a).size()
#define ppc                         __builtin_popcount
#define ppcll                       __builtin_popcountll
#define mem1(a)                     memset(a,-1,sizeof(a))
#define mem0(a)                     memset(a,0,sizeof(a))
#define endl                        "\n"
#define lb                          lower_bound
#define ub                          upper_bound
template<class T> using ordered_set =  tree<T, null_type,less<T>,rb_tree_tag,tree_order_statistics_node_update>;
template<class T> using ordered_multiset = tree<T, null_type,less_equal<T>,rb_tree_tag,tree_order_statistics_node_update>;
const ld PI = acos(-1.0);
const int MOD = 1e9 +7;
const ll INF = 1e18;
// if(abs(a-b)<eps) --> if(a==b)
// fixed << setprecision(n) -->printing decimal till n
// hypot(a ,b) --> sqrt(a^2 + b^2)

void solve(){
    ll n;
    cin>>n;
    vector<ll>adj[n];
    for(int i=0;i<n-1;i++){
        ll a ,b;
        cin>>a>>b;
        a--;b--;
        adj[a].pb(b);
        adj[b].pb(a);
    }

    vector<ll>val(n);
    for(int i=0;i<n;i++){
        cin>>val[i];
    }

    //Now part is parent part(by euler)
    //some child subtree part
    vector<ll>st(n) , en(n);
    vector<ll>par(n,0);
    ll time =0;
    function<void(ll ,ll)> dfs=[&](ll root , ll parent){
        st[root] = time;
        par[root] = parent;
        for(auto it : adj[root]){
            if(it==parent) continue;
            time++;
            dfs(it ,root);
        }
        en[root] = time;
    };
    dfs(0, -1);

    vector<ll>A(n);
    for(int i=0;i<n;i++){
        A[st[i]] = val[i];
    }

    int max_len = log2(n); 
    vector<vector<ll>>dp(n,vector<ll>(max_len+1));
    for(int j=0;j<=max_len;j++){
        for(int i=0;i+(1<<j)-1<n;i++){
             if(j==0){
                dp[i][j] = A[i];
             }
             else{
                dp[i][j] = __gcd(dp[i][j-1] , dp[i+(1<<(j-1))][j-1]);
             }
         }
    }
    // Query:  =  __gcd(dp[l][len] , dp[r-(1<<len)+1][len]);

    ll ans = INF;
    for(int i=0;i<n;i++){
        ll cost =0;
        for(auto it : adj[i]){
            if(it==par[i]) continue;
            ll l=st[it];
            ll r=en[it];
            int len = log2(r-l+1);
            ll gcds = __gcd(dp[l][len] , dp[r-(1<<len)+1][len]);
            cost += gcds;
        }

        //dont take his subtree and remain will go on a component

        if(par[i]==-1){
            ans = min(ans , cost);
            continue;
        }

        ll lgcd=0 , rgcd=0;
        ll l=0;
        ll r=st[i] - 1;
        if(l<=r){
            int len = log2(r-l+1);
            lgcd = __gcd(dp[l][len] , dp[r-(1<<len)+1][len]);
        }

        l=en[i] +1;
        r=n-1;
        if(l<=r){
            int len = log2(r-l+1);
            rgcd = __gcd(dp[l][len] , dp[r-(1<<len)+1][len]);
        }
        cost += __gcd(lgcd , rgcd);
        ans = max(ans , cost);
    }
    cout<<ans<<endl;

}

int main(){
    IO;
    ll t =1;
    cin>>t;
    for(int i=1;i<=t;i++){
        // cout<<"Case #"<<i<<": ";
        solve();
    }
    return 0;
}