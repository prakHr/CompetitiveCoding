
#include <bits/stdc++.h>
#define fre freopen("input.txt", "r", stdin);
#define open freopen("output.txt", "w", stdout);
#define K4ay cin.tie(0);ios::sync_with_stdio(0);cout.tie(0);
#define fi first
#define se second
#define pb push_back
#define OOO cerr<<">>";
using namespace std;
typedef long long ll;
typedef long double ld;
ll parent[100001];
ll sz[100001];
ll flag[100001];
void make_set(int v, int res) {
    parent[v]=v;
    sz[v]=1;
    if (res==1) flag[v]=1;
    else flag[v]=0;
}

int find_set(int v) {
    if (v==parent[v]) {
        return v;
    }
    return parent[v]=find_set(parent[v]);
}

void unite(int a, int b) {
    a=find_set(a);
    b=find_set(b);
    if (a!=b) {
        if (sz[a]<sz[b]) swap(a,b);
        parent[b]=a;
        sz[a]+=sz[b];
        if (flag[b]==1) {
            flag[a]=1;
        }
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin >> t;
    while (t--) {
        ll n,m;
        cin >> n >> m;
        string s;
        cin >> s;
        s="'"+s;
        for (int i=1;i<=n;i++){
            if (s[i]=='H')make_set(i,0);
            else make_set(i,1);
        }
        multimap<ll, pair<ll,ll>> mm;
        for (int i = 0;i<m;i++) {
            ll u, v, cost;
            cin >> u >> v >> cost;
            mm.insert({cost,{u,v}});
        }
        ll ans = 0;
        ll a, b;
        for (auto it : mm) {
            a = find_set(it.se.fi);
            b= find_set(it.se.se);
            if (it.first<=0) {
                unite(a, b);
                ans+=it.fi;
            }
            else {
                if ((flag[a]==0 or flag[b]==0) and a!=b) {
                    unite(a, b);
                    ans+=it.fi;
                }
            }
        }
        cout << ans << "\n";

    }
}