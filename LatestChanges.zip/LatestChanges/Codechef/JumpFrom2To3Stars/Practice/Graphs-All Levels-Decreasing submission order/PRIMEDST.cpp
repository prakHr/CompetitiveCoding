#include <bits/stdc++.h>
 
using namespace std;
 
#define fixed(n) fixed << setprecision(n)
#define ceil(n, m) (((n) + (m) - 1) / (m))
#define add_mod(a, b, m) (((a % m) + (b % m)) % m)
#define sub_mod(a, b, m) (((a % m) - (b % m) + m) % m)
#define mul_mod(a, b, m) (((a % m) * (b % m)) % m)
#define all(vec) vec.begin(), vec.end()
#define rall(vec) vec.rbegin(), vec.rend()
#define sz(x) int(x.size())
#define debug(x) cout << #x << ": " << (x) << "\n";
#define fi first
#define se second
#define ll long long
#define ull unsigned long long
#define EPS 1e-9
constexpr int INF = 1 << 30, Mod = 1e9 + 7;
constexpr ll LINF = 1LL << 62;
#define PI acos(-1)
template < typename T = int > using Pair = pair < T, T >;
vector < string > RET = {"NO", "YES"};
 
template < typename T = int > istream& operator >> (istream &in, vector < T > &v) {
    for (auto &x : v) in >> x;
    return in;
}
 
template < typename T = int > ostream& operator << (ostream &out, const vector < T > &v) { 
    for (const T &x : v) out << x << ' '; 
    return out;
}
 
constexpr int MAX = 5e4 + 5;

struct Centroid_Decomposition {
 
    int n, treeRoot, k, max_depth;
    const vector < vector < int > > adj;
    int SubtreeSz[MAX], isCentroid[MAX], cnt[MAX];
    vector < int > primes;
    bool isPrime[MAX];
    ll ans;
 
    // Initialize the Centroid Decomposition
    Centroid_Decomposition(int N, const vector < vector < int > > &G, int Root = 1) : adj(G){
        n = N, treeRoot = Root, ans = 0, max_depth = 0;
        memset(isCentroid, 0, sizeof(isCentroid));
        memset(isPrime, 1, sizeof(isPrime));
        memset(cnt, 0, sizeof(cnt));
        memset(SubtreeSz, 0, sizeof(SubtreeSz));
        sieve(n);
    }
 
    // check if a number is prime or not
    void sieve(int N){
        isPrime[0] = isPrime[1] = false;
        for(int i = 2; i * i <= N; i++){
            if(!isPrime[i]) continue;
            for(int j = i * i; j <= N; j += i)
                isPrime[j] = false;
        }
        for(int i = 2; i <= N; i++)
            if(isPrime[i]) 
                primes.push_back(i);
    }

    // update subtree size of each node
    int updateSize(int u, int p = -1){
        SubtreeSz[u] = 1;
        for (int v : adj[u]) 
            if (v != p && !isCentroid[v]) 
                SubtreeSz[u] += updateSize(v, u);
        return SubtreeSz[u];
    }
 
    // get centroid of subtree rooted at u
    int getCentroid(int u, int target, int p = -1){
        for(auto& v : adj[u]){
            if(v == p || isCentroid[v]) continue;
            if(SubtreeSz[v] * 2 > target) 
                return getCentroid(v, target, u);
        }
        return u;
    }
 
    void dfs(int u, int p = 0, bool isFilling = false, int depth = 1){
        if(isFilling) cnt[depth]++;
        else if(isFilling == 0) {
            for(auto& pr : primes)
                if(pr >= depth)
                    ans += cnt[pr - depth];
        }
 
        max_depth = max(max_depth, depth);

        for(auto& v : adj[u]){
            if(v == p || isCentroid[v]) continue;
            dfs(v, u, isFilling, depth + 1);
        }
    }
 
    // decompose tree into centroid tree
    void Centroid(int u, int p = 0){
        int centroidPoint = getCentroid(u, updateSize(u));
        isCentroid[centroidPoint] = true;

        max_depth = 0;

        for(auto& v : adj[centroidPoint]){
            if(v == p || isCentroid[v]) continue;
            dfs(v, centroidPoint, false);
            dfs(v, centroidPoint, true);
        }

        fill(cnt + 1, cnt + max_depth + 1, 0);

        for(auto& v : adj[centroidPoint]){
            if(v == p || isCentroid[v]) continue;
            Centroid(v, centroidPoint);
        }
    }
    
    ll getAns(){
        cnt[0] = 1;
        Centroid(treeRoot);
        return ans;
    }
 
};
 
void Solve(){
    int n;
    cin >> n;
    vector < vector < int > > adj(n + 5);
    for(int i = 1, u, v; i < n && cin >> u >> v; i++)
        adj[u].push_back(v), adj[v].push_back(u);
    Centroid_Decomposition CD(n, adj);
    ll all_paths = 1LL * n * (n - 1) / 2;
    ll prime_paths = CD.getAns();
    cout << fixed(6) << 1.0 * prime_paths / all_paths << '\n';
}
 
int main(){
    ios_base::sync_with_stdio(false), cin.tie(nullptr), cout.tie(nullptr);
    int test_cases = 1;
    // cin >> test_cases;
    for(int tc = 1; tc <= test_cases; tc++){
        // cout << "Case #" << tc << ": ";
        Solve();
    }
    return 0;
}
