#x=list(map(int,input().split()))
tests=int(input())
for t in range(tests):
    pass
    
