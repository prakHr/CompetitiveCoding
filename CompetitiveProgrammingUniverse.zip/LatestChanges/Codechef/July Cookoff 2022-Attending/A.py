from itertools import permutations 

def check(arr):
    for i in range(0,len(arr)-2):
        if (arr[i]^arr[i+1])==arr[i+2]:
            return False
    return True
def findMedian(a, n):
 
    # First we sort the array
    a=sorted(a)
    if n%2==0:
        return a[int(n/2)-1]
    return a[int(n/2)]

'''
True
For 1
[1]
For 2
[2, 1]
For 3
[3, 1, 2]
For 4
[4, 1, 3, 2]
For 5
[5, 1, 4, 2, 3]
For 6
[6, 1, 5, 2, 4, 3]
'''
    
def check2(arr):
    for i in range(len(arr)):
        curr=arr[i]
        currArr = arr[:i+1]
        #print(f"{curr}=>{findMedian(currArr,len(currArr))}")
        if curr!=findMedian(currArr,len(currArr)):
            return False
    return True
print(check2([3,1,2]))
for x in range(1,7):
    print(f"For {x}")
    a = list(range(1,x+1))

    # no length entered so default length
    # taken as 4(the length of string GeEK)
    p = permutations(a) 

    flag=False      
    # Print the obtained permutations 
    for j in list(p):
        y =list(j)

        if(check2(y) and flag==False):
            print(y)
            flag=False
            
'''        
For 4
[1, 2, 4, 3]
For 5
[1, 2, 4, 3, 5]
For 6
[1, 2, 5, 3, 4, 6]
For 7
[1, 2, 4, 3, 5, 7, 6]
For 8
[1, 2, 4, 3, 5, 7, 6, 8]
For 9
[1, 2, 4, 3, 5, 7, 6, 8, 9]
For 10
[1, 2, 4, 3, 5, 7, 6, 8, 9, 10]
For 11
[1, 2, 4, 3, 5, 7, 6, 8, 9, 10, 11]
'''
