// C++ program to find minimum steps to reach to
// specific cell in minimum moves by Knight
#include <bits/stdc++.h>
using namespace std;
 

// Driver code to test above methods
int main()
{
	int t;
	cin>>t;
	while(t--){
		int N;
	    cin>>N;
	    int a=0,b=0,c=0;
	    for(int i=0;i<N;i++){
	    	int x;
	    	cin>>x;
	    	if(x%3==2){
	    		a++;
			}
			if(x%3==1){
				b++;
			}
			if(x%3==0){
				c++;
			}
		}
		
		int ans1=min(a,b);
		int ans2=(a-ans1)/3+(b-ans1)/3;
		int ans=ans1+2*ans2;
		if((0*c+1*b+2*a)%3)ans=-1;
		cout<<ans<<endl;
//		if(a==b){
//			
//			cout<<a<<endl;
//		}
//		else if(2*a==b){
//			cout<<b<<endl;
//		}
//		else if(2*b==a){
//			cout<<a<<endl;
//		}
//		else cout<<-1<<endl;
	}
	
    return 0;
}