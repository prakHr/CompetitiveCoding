tests=int(input())
for test in range(tests):
    #n=int(input())
    a,b=list(map(int,input().split()))
    s=a+b
    if s%2==0:
        print('Bob')
    else:print('Alice')
    #print(arr)
    #pass
