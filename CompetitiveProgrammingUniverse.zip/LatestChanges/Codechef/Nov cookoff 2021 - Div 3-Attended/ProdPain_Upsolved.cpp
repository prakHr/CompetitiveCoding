#include<bits/stdc++.h>
#define int long long
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

typedef vector<int> vi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef vector<vii> vvii;

#define INF INT_MAX
#define MOD 1000000007
#define all(x) x.begin(), x.end()

int32_t main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int T; cin >> T;
    while(T--){
        int N; cin >> N;
        vi A(N); for(auto &i : A) cin >> i;

        int ans = 0;
        for(int l = 0; l < N; l++){
            for(int r = l+2; r < N; r++){
                auto f=[&](int j){
                	return (A[l]-A[j])*(A[j]-A[r]);
				};
				int j=upper_bound(A.begin()+l,A.begin()+r,(A[l]+A[r])/2)-A.begin();
				j=min(j,r-1);
				ans += max(f(j),f(j-1));
            }
        }
        cout << ans << endl;
    }

    return 0;
}