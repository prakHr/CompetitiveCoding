tests=int(input())
for t in range(tests):
    pass
    
