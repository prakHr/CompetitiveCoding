#include <bits/stdc++.h>
#define FAST_IO ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define pb push_back
#define eb emplace_back
#define mp make_pair
#define mt make_tuple
#define PI acos(-1)
#define sqr(a) ((a)*(a))
#define ff first
#define ss second
#define sf scanf
#define pf printf
#define pf1(a) pf("%lld", a);
#define pf2(a,b) pf("%lld %lld", a, b)
#define pf3(a,b,c) pf("%lld %lld %lld", a, b, c)
#define sf1(a) sf("%lld", &a)
#define sf2(a,b) sf("%lld %lld", &a, &b)
#define sf3(a,b,c) sf("%lld %lld %lld", &a, &b, &c)
#define sf4(a,b,c,d) sf("%lld %lld %lld %lld", &a, &b, &c, &d)
#define sf5(a,b,c,d,e) sf("%lld %lld %lld %lld %lld", &a, &b, &c, &d, &e)
#define sfc(a) sf(" %c", &a)
#define sfd(n) sf("%lf", &n)
#define FOR(i, j, k, in) for (int i=j ; i<k ; i+=in)
#define RFOR(i, j, k, in) for (int i=j ; i>=k ; i-=in)
#define REP(i, j) FOR(i, 0, j, 1)
#define RREP(i, j) RFOR(i, j, 0, 1)
#define FOREACH(it, l) for (auto it = l.begin(); it != l.end(); it++)
#define RESET(a, b) memset(a, (b), sizeof(a))
#define lb lower_bound
#define ub upper_bound
#define nl pf("\n")
#define endl '\n'
#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define SZ(v) (int)v.size()
#define ALL(v) v.begin(), v.end()
#define SORT(v) sort(ALL(v))
#define REVERSE(v) reverse(ALL(v))
#define UNIQUE(v) (v).erase(unique((v).begin(), (v).end()), (v).end())
#define on(n,i) (n|=(1LL<<i))
#define isOn(n,i) (n&(1LL<<i))
#define off(n,i) (n = isOn(n,i) ? n ^ (1LL<<i) : n)
#define gcd(a,b) __gcd(a,b)
#define lcm(a,b) (a/gcd(a,b)*b)
#define watch(a) cout << (#a) << " is " << (a) << '\n'
#define watch2(a,b) cout << (#a) << " is " << (a) << " and " << (#b) << " is " << (b) << '\n'
#define MIN3(a,b,c) MIN(a, MIN(b,c))
#define MAX3(a,b,c) MAX(a, MAX(b,c))
 
using namespace std;
typedef long long ll; 
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<string> vs;
typedef vector<pii> vii;
typedef vector<vi> vvi;
typedef map<int,int> mpii;
typedef set<int> seti;
typedef multiset<int> mseti;
typedef tuple<int,int,int> State;
 
template <class T>  inline void chmax(T &x,T &y) {if(x < y) swap(x,y);}
template <class T>  inline void chmin(T &x,T &y) {if(x > y) swap(x,y);}
 
/*----------------------Graph Moves----------------*/
//const int fx[]={+1,-1,+0,+0};
//const int fy[]={+0,+0,+1,-1};
//const int fx[]={+0,+0,+1,-1,-1,+1,-1,+1};   // Kings Move
//const int fy[]={-1,+1,+0,+0,+1,+1,-1,-1};  // Kings Move
//const int fx[]={-2, -2, -1, -1,  1,  1,  2,  2};  // Knights Move
//const int fy[]={-1,  1, -2,  2, -2,  2, -1,  1}; // Knights Move
/*------------------------------------------------*/
 
const int INF = 0x3f3f3f3f3f3f;
const int MOD = 1e9 + 7;
const double EPS = 10e-10;

const ll P2LIM=(ll)2e18;

mpii useDivisors;
// C++ program to count distinct divisors
// of a given number n
#include <bits/stdc++.h>
using namespace std;

void SieveOfEratosthenes(int n, bool prime[],
						bool primesquare[], int a[])
{
	
	//For more details check out: https://www.geeksforgeeks.org/sieve-of-eratosthenes/
	
	// Create a boolean array "prime[0..n]" and
	// initialize all entries it as true. A value
	// in prime[i] will finally be false if i is
	// Not a prime, else true.
	for (int i = 2; i <= n; i++)
		prime[i] = true;

	// Create a boolean array "primesquare[0..n*n+1]"
	// and initialize all entries it as false. A value
	// in squareprime[i] will finally be true if i is
	// square of prime, else false.
	for (int i = 0; i <= (n * n + 1); i++)
		primesquare[i] = false;

	// 1 is not a prime number
	prime[1] = false;

	for (int p = 2; p * p <= n; p++) {
		// If prime[p] is not changed, then
		// it is a prime
		if (prime[p] == true) {
			// Update all multiples of p starting from p * p
			for (int i = p * p; i <= n; i += p)
				prime[i] = false;
		}
	}

	int j = 0;
	for (int p = 2; p <= n; p++) {
		if (prime[p]) {
			// Storing primes in an array
			a[j] = p;

			// Update value in primesquare[p*p],
			// if p is prime.
			primesquare[p * p] = true;
			j++;
		}
	}
}

// Function to count divisors
int countDivisors(int n)
{
	// If number is 1, then it will have only 1
	// as a factor. So, total factors will be 1.
	if (n == 1)
		return 1;

	bool prime[n + 1], primesquare[n * n + 1];

	int a[n]; // for storing primes upto n

	// Calling SieveOfEratosthenes to store prime
	// factors of n and to store square of prime
	// factors of n
	SieveOfEratosthenes(n, prime, primesquare, a);

	// ans will contain total number of distinct
	// divisors
	int ans = 1;

	// Loop for counting factors of n
	for (int i = 0;; i++) {
		// a[i] is not less than cube root n
		if (a[i] * a[i] * a[i] > n)
			break;

		// Calculating power of a[i] in n.
		int cnt = 1; // cnt is power of prime a[i] in n.
		while (n % a[i] == 0) // if a[i] is a factor of n
		{
			n = n / a[i];
			cnt = cnt + 1; // incrementing power
		}

		// Calculating the number of divisors
		// If n = a^p * b^q then total divisors of n
		// are (p+1)*(q+1)
		ans = ans * cnt;
	}

	// if a[i] is greater than cube root of n

	// First case
	if (prime[n])
		ans = ans * 2;

	// Second case
	else if (primesquare[n])
		ans = ans * 3;

	// Third case
	else if (n != 1)
		ans = ans * 4;

	return ans; // Total divisors
}

// Driver Program
//int main()
//{
//	cout << "Total distinct divisors of 100 are : "
//		<< countDivisors(100) << endl;
//	return 0;
//}

int countDivisors2(int n)
{
    int cnt = 0;
    for (int i = 1; i <= sqrt(n); i++) {
        if (n % i == 0) {
            // If divisors are equal,
            // count only one
            if (n / i == i)
                cnt++;
 
            else // Otherwise count both
                cnt = cnt + 2;
        }
    }
    return cnt;
}
void WrongSolution() {
	int num;
	cin>>num;

	int ans=INT_MIN;
	int square_root = (int) sqrt(num) + 1;
	for (int i = 1; i < square_root; i++) { 
//    	if (num % i == 0 && i*i!=num)
//    	{
////    			useDivisors[i]++;
////    			useDivisors[num/i]++;
////				ans=max(ans,useDivisors[i]);
////				ans=max(ans,useDivisors[num/i]);
//				ans=max(ans,countDivisors(i));
//				ans=max(ans,countDivisors(num/i));
//				
//		}
////        	cout << i << num/i << endl;
//    	if (num % i == 0 && i*i==num){
////    		useDivisors[i]++;
////    		ans=max(ans,useDivisors[i]);
//			ans=max(ans,countDivisors(i));
//		}

//        	cout << i << '\n';
		ans=max(ans,countDivisors(i));
	}
//	cout<<"ans:"<<ans<<endl;
//	cout<<ans<<endl;
	for (int i = 1; i < square_root; i++) { 
		if(ans==countDivisors(i)){
			if(i==1){
				cout<<num<<endl;
				return;
			}
			cout<<min(i,num/i)<<endl;
			return;
		}
//		if (num % i == 0 && i*i!=num){
//			if(ans==countDivisors(i)){
//				cout<<"Here\n";
//				cout<<(num/i)<<endl;
//				return;
//			}
//			if(ans==countDivisors(num/i)){
//				cout<<"Here1\n";
//				cout<<i<<endl;
//				return;
//			}
//		}
//		if (num % i == 0 && i*i==num){
//			if(ans==countDivisors(i)){
//				cout<<"Here3\n";
//				cout<<num/i<<endl;
//			}
//		}
		
	
	}
}	
// factors = 2*4
// factors = 2-1*4 or 2*4-1
// so we have to take the prime factor pf with maximum power 
// for better ans and the first one from forward iteration
void Solution(){
	int n;
	cin>>n;
	int maxPower=0,minFactor=1e9;
	for(int pf=2;pf*pf<=n;pf++){
		if(n%pf==0){
			int currentPower=0;
			while(n%pf==0){
				n=n/pf;
				currentPower++;
			}
			if(currentPower>maxPower){
				maxPower=currentPower;
				minFactor=pf;
			}
		}
	}
	if(maxPower==0)minFactor=n;
	cout<<minFactor<<endl;
}

int32_t main() {
//   	FAST_IO;
    int tc;
	cin>>tc;
	
    FOR(tn,1,tc+1,1) {
        
        Solution();  
	}
 
    return 0;
}


