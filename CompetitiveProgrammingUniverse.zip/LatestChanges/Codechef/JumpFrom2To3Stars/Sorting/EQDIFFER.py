import collections
#does not work
for _ in range(int(input())):
    n=int(input())
    arr=list(map(int,input().split()))
    if n==1 or n==2:
        print(0)
    else:
        c = collections.Counter(arr)
        
        x = max(c.values())
        if len(c.values())>=2:
            print(min(n-x,n-2))
        else:
            print(min(n-x))
