for l in range(1,10):
    for r in range(l,10):
        # r-l = 0 ,1 (2*(r-l)+1)
        # r-l = 1 ,3
        # r-l = 2 ,5
        # r-l = 1 ,3
        # r-l = 1 ,3
        ans=set()
        for i in range(l,r+1):
            for j in range(l,r+1):
                ans.add(i+j)
        print(l,r,len(ans))
                
