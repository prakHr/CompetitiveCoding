from itertools import permutations
for i in range(2,7):
    n = i
    # [2,1] n=2
    # [2,3,1] n= 3
    # [2,3,4,1] n=4
    arr = list(range(1,n+1))
    p = permutations(arr)
    ans=[]
    for i in list(p):
        x = list(i)
        k = 2
        flag=False
        for j in x[1:]:
            if j%k==0:
                flag=True
                break
            k+=1
        if flag==False:
            ans.append(x)
    print(ans)
