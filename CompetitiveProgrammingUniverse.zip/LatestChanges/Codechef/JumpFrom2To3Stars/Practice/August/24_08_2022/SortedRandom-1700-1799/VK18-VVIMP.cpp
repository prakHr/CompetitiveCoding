#include <bits/stdc++.h>
#define FAST_IO ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define int long long
#define pb push_back
#define eb emplace_back
#define mp make_pair
#define mt make_tuple
#define PI acos(-1)
#define sqr(a) ((a)*(a))
#define ff first
#define ss second
#define sf scanf
#define pf printf
#define pf1(a) pf("%lld", a);
#define pf2(a,b) pf("%lld %lld", a, b)
#define pf3(a,b,c) pf("%lld %lld %lld", a, b, c)
#define sf1(a) sf("%lld", &a)
#define sf2(a,b) sf("%lld %lld", &a, &b)
#define sf3(a,b,c) sf("%lld %lld %lld", &a, &b, &c)
#define sf4(a,b,c,d) sf("%lld %lld %lld %lld", &a, &b, &c, &d)
#define sf5(a,b,c,d,e) sf("%lld %lld %lld %lld %lld", &a, &b, &c, &d, &e)
#define sfc(a) sf(" %c", &a)
#define sfd(n) sf("%lf", &n)
#define FOR(i, j, k, in) for (int i=j ; i<k ; i+=in)
#define RFOR(i, j, k, in) for (int i=j ; i>=k ; i-=in)
#define REP(i, j) FOR(i, 0, j, 1)
#define RREP(i, j) RFOR(i, j, 0, 1)
#define FOREACH(it, l) for (auto it = l.begin(); it != l.end(); it++)
#define RESET(a, b) memset(a, (b), sizeof(a))
#define lb lower_bound
#define ub upper_bound
#define nl pf("\n")
#define endl '\n'
#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define SZ(v) (int)v.size()
#define ALL(v) v.begin(), v.end()
#define SORT(v) sort(ALL(v))
#define REVERSE(v) reverse(ALL(v))
#define UNIQUE(v) (v).erase(unique((v).begin(), (v).end()), (v).end())
#define on(n,i) (n|=(1LL<<i))
#define isOn(n,i) (n&(1LL<<i))
#define off(n,i) (n = isOn(n,i) ? n ^ (1LL<<i) : n)
#define gcd(a,b) __gcd(a,b)
#define lcm(a,b) (a/gcd(a,b)*b)
#define watch(a) cout << (#a) << " is " << (a) << '\n'
#define watch2(a,b) cout << (#a) << " is " << (a) << " and " << (#b) << " is " << (b) << '\n'
#define MIN3(a,b,c) MIN(a, MIN(b,c))
#define MAX3(a,b,c) MAX(a, MAX(b,c))

using namespace std;
typedef long long ll; 
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<string> vs;
typedef vector<pii> vii;
typedef vector<vi> vvi;
typedef map<int,int> mpii;
typedef set<int> seti;
typedef multiset<int> mseti;
typedef tuple<int,int,int> State;
 
template <class T>  inline void chmax(T &x,T &y) {if(x < y) swap(x,y);}
template <class T>  inline void chmin(T &x,T &y) {if(x > y) swap(x,y);}
 
/*----------------------Graph Moves----------------*/
const int dx[]={+1,-1,+0,+0};
const int dy[]={+0,+0,+1,-1};
//const int fx[]={+0,+0,+1,-1,-1,+1,-1,+1};   // Kings Move
//const int fy[]={-1,+1,+0,+0,+1,+1,-1,-1};  // Kings Move
//const int fx[]={-2, -2, -1, -1,  1,  1,  2,  2};  // Knights Move
//const int fy[]={-1,  1, -2,  2, -2,  2, -1,  1}; // Knights Move
/*------------------------------------------------*/
 
const int INF = 0x3f3f3f3f3f3f;
const int MOD = 1e9 + 7;
const double EPS = 10e-10;

const ll P2LIM=(ll)2e18;

const int N = 1e6+10;
int val[2*N];
int prefixVal[2*N],ans[N];
void init(){
	prefixVal[0]=0;
	val[0]=0;
	FOR(i,1,2*N,1){
		int x=i;
		while(x>0){
			int d=x%10;
			if(d&1)val[i]+=d;
			else val[i]-=d;
			x/=10;
		}
		val[i]=abs(val[i]);
		prefixVal[i]=prefixVal[i-1]+val[i];
	}
	ans[1]=val[2];
	FOR(i,2,N,1){
		// by one based indexing
		// 2*(prefix(2N+1)-prefix(N+1))
		// how do we get this
		// in last row = f(1,N)+f(2,N)+...f(N,N)
		// in last col = f(N,1)+f(N,2)+...f(N,N)
		// f(i,j) = f(i+j)
		// so if f(1+n)+f(2+n)+...f(n+n) = (f(1)+f(2)+...f(n)+f(1+n)+f(2+n)+...f(n+n))-(f(1)+f(2)+...f(n)) 
		//(last column is symmetric so we can multiply by 2 and consider only lower half of the matrix)
		// so instead of filling N by N matrix we can fill N rows matrix
		// so contribution is last row + last col = 2*last row
		// ans+=2*((f(1)+f(2)+...f(n)+f(1+n)+f(2+n)+...f(n+n))-(f(1)+f(2)+...f(n)))
		// ans+=2*(prefixSum[2*n-1](We are taking only till second last)-prefixSum[n])
		// also (lastcell+1,lastcell+1) will contribute individually
		ans[i]=ans[i-1]+2LL*(prefixVal[2*i-1]-prefixVal[i])+val[2*i];
	}
}
void Solution(){
	int n;
	cin>>n;
	cout<<ans[n]<<endl;
} 

int32_t main() {
	init();
	FAST_IO;
	int t=1;
	cin>>t;
	REP(i,t){
		Solution();
	}
    return 0;
}

