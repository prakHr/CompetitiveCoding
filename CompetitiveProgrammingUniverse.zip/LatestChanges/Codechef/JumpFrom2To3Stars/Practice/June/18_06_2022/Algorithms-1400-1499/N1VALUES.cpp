#include<bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    ll a[62];
    for(ll i=1;i<62;i++){
        a[i]=(1LL<<i);
    }
    ll t;
    cin>>t;
    while(t--){
        ll n;
        cin>>n;
        if(n==1) cout<<1<<" "<<1<<"\n";
        else if(n==2) cout<<1<<" "<<1<<" "<<2<<"\n";
        else{
            ll count=a[n];
            cout<<1<<" "<<1<<" ";
            count-=2;
            for(ll i=2;i<n;i++){
                cout<<i<<" ";
                count-=i;
            }
            cout<<count<<"\n";
        }
    }

    return 0;
}