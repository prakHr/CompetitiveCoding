#include <iostream>
#include<vector>
#include<algorithm>

using namespace std;

template<typename T>
void printArr(T* arr, int n){
    for(int i = 0; i < n ; i++){
        cout << arr[i] << " ";
    }
    cout << endl;
}
void getArr(int* arr, int n){
    // int* arr = new int[n]; 
    for(int i = 0; i < n; i++){
        cin >> arr[i];
    }
    return;
}

int main() {
	// your code goes here
	ios_base::sync_with_stdio(false);
	cin.tie(NULL), cout.tie(NULL);
	
	int n;
	cin >> n;
	char matr[n][n];
	
	for(int i = 0; i < n; i++){
	    
	    for(int j = 0; j < n; j++){
	        cin >> matr[i][j];
	    }
	}
	
	int B[n][n];
	
	for(int i = 0; i < n; i++){
	    for(int j = 0; j < n; j++){
	        if(matr[i][j] == '.'){
	            B[i][j] = 0;
	            cout << B[i][j] << " ";
	        }
	        else{
	            int count[4];
	            count[0] = 1;
	            count[1] = 1;
	            count[2] = 1;
	            count[3] = 1;
	            int max;
	            
	            int k, l;
                
                for(k = i, l = j+1; l >= 0 && l < n && k >= 0 && k < n; l++){
	                if(matr[k][l] == 'X'){
	                    count[0]++;
	                }
	                else{
	                    break;
	                }
	            }
	            for(k = i, l = j-1; l >= 0 && l < n && k >= 0 && k < n; l--){
	                if(matr[k][l] == 'X'){
	                    count[0]++;
	                }
	                else{
	                    break;
	                }
	            }
	            
	            for(k = i-1, l = j; l >= 0 && l < n && k >= 0 && k < n; k--){
	                if(matr[k][l] == 'X'){
	                    count[1]++;
	                }
	                else{
	                    break;
	                }
	            }
	            for(k = i+1, l = j; l >= 0 && l < n && k >= 0 && k < n; k++){
	                if(matr[k][l] == 'X'){
	                    count[1]++;
	                }
	                else{
	                    break;
	                }
	            }
	            
	            for(k = i+1, l = j+1; l >= 0 && l < n && k >= 0 && k < n; l++,k++){
	                if(matr[k][l] == 'X'){
	                    count[2]++;
	                }
	                else{
	                    break;
	                }
	            }
	            for(k = i-1, l = j-1; l >= 0 && l < n && k >= 0 && k < n; l--,k--){
	                if(matr[k][l] == 'X'){
	                    count[2]++;
	                }
	                else{
	                    break;
	                }
	            }
	            
	            for(k = i-1, l = j+1; l >= 0 && l < n && k >= 0 && k < n; l++,k--){
	                if(matr[k][l] == 'X'){
	                    count[3]++;
	                }
	                else{
	                    break;
	                }
	            }
	            for(k = i+1, l = j-1; l >= 0 && l < n && k >= 0 && k < n; l--,k++){
	                if(matr[k][l] == 'X'){
	                    count[3]++;
	                }
	                else{
	                    break;
	                }
	            }
	            
	        
	            max = *(max_element(count, count+4));
	            B[i][j] = max;
	            cout << B[i][j] << " ";
	        }
	    }
	
	    cout << endl;
	}
	
	
	
	return 0;
}
