import itertools
from itertools import permutations 
  
def check(list):
    for i in range(1,len(list)-1):
        if list[i]*list[i]==list[i-1]*list[i+1]:
            return False
    return True  

 
#a = [1,-1,-1,-1,-1,1]
#[-1, -1, 1, 1, -1, -1]

#a = [1,-1,-1,-1,-1,-1] No

#a = [1,-1,-1,-1,1,1]
#[1, -1, -1, 1, 1, -1]

#a =  [-1,-1,-1,-1,-1,-1] No

#a = [-1, -1, 1, 1, 1,1]
#[1, 1, -1, -1, 1, 1]

#a = [-1, -1, -1, -1, -1,1] No

#a = [-1,-1,-1,-1,1] No

#a = [-1,-1,-1,1,1]
#[-1, -1, 1, 1, -1]

#a=[-1,-1,1, 1,1]
#[1, 1, -1, -1, 1]
#a=[-1,1,1, 1,1] No
#a = [-1,1,1,1] No
a = [-1,-1,1,1]
# no length entered so default length
# taken as 4(the length of string GeEK)
p = permutations(a) 
  
# Print the obtained permutations 
for j in list(p):
    if(check(list(j))):
        print(list(j)) 
