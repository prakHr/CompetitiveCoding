def powerOfDigits(s):
    ans = 0
    while s>0:
        ans += s%10
        s = s//10
    return ans
arr = []
arr.append(0)
i=1
while True:
    
    s = int('9'*i)
    print(powerOfDigits(s))
    if powerOfDigits(s)>1000000:
        break
    arr.append(s)
    i += 1
    
    
n = len(arr)
print(n)
#for i in range(n-1):
#    print(f"{i+1}->{powerOfDigits(arr[i])} {i+2}->{powerOfDigits(arr[i+1])}")
