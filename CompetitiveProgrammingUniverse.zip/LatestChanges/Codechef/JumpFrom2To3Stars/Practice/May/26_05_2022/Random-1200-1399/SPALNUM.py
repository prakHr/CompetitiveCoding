
LIMIT = pow(10,5)
cnt1 = 0
s = set()
for i in range(1,LIMIT+1):
    x=str(i)
    if x==x[::-1]:
        s.add(x)
t=int(input())
for _ in range(t):
    l,r=list(map(int,input().split()))
    ans=0
    for i in range(l,r+1):
        if str(i) in s:
            ans+=i
    print(ans)
