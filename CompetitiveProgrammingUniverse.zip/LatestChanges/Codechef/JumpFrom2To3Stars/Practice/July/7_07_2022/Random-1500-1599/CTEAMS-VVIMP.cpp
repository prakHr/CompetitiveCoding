#include <bits/stdc++.h>
using namespace std;
typedef pair<long long int,long long int> pll;
int main()
{
    long long int t,a,r,so=0,sy=0;
    pll p;
    priority_queue <pll> y;
    priority_queue <pll, vector<pll>, greater<pll>> o;
    cin>>t;
    while(t--)
    {
        cin>>a>>r;
        if(o.empty()||a<o.top().first)
        {
            y.push(make_pair(a,r));
            sy = sy + r;
        }
        else
        {
            o.push(make_pair(a,r));
            so = so + r;
        }
        if(y.size()>o.size()+1)
        {
            p=y.top();
            sy = sy - p.second;
            y.pop();
            o.push(p);
            so = so + p.second;
        }
        else if(o.size()>y.size())
        {
            p=o.top();
            so = so - p.second;
            o.pop();
            y.push(p);
            sy = sy + p.second;
        }
        cout<<abs(so-sy)<<endl;
    }   
}