'''
[1,2]
[1]
[2]


[1,2,3]
[1,3] 2*a or 2*b
[2]   1*b or 1*a

[1,2,3,4]
[1,3] 2a or 2b
[2,4] 2b or 2a

[1,2,3,4,5]
[1,3,5] 3a or 3b
[2,4]   2b or 2a
(2a,b) or (2b,a)
(2a,2b) or (2b,2a)
(3a,2b) or (3b,2a)
(4a,3b) or (4b,3a)
compare with p,q
after division difference should be <=1
'''                
