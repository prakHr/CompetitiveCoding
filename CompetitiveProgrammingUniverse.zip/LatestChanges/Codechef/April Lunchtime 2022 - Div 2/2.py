from itertools import permutations
from pprint import pprint

for x in range(1,6):
    for y in range(1,6):
        perms=[]
        print(x,y)
        string= x*'a'+y*'b'
        #print(permutations(string))
        un=set()
        for c in permutations(string):
            un.add("".join(c))
        perms=[]
        un=list(un)
        for c in un:
            #print(c)
            temp=c
            if temp==temp[::-1]:
                perms.append(temp)
        print(perms)
        print("*"*50)
              
