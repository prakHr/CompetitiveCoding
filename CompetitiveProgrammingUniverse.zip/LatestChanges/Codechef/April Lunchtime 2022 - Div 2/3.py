arr=[2,3,2,3,5,1,5,2,3,2,3,5,1,5,2,2,2,2]
print(len(arr))
#20
#18
#2 3 2 3 5 1 5 2 3 2 3 5 1 5 2 2 2 2
# 18
# 2 2 => 6(4-1=3,3+2+1)
# 1 1 => 1

# 2 2 => 28(8-1=7,7+6+5+4+3+2+1)
# similarly for 1 1 => 1
# rest is only count if 1 is present on left side
# 28+1+5+11+11+5=
# store the position in sorted order and then do binary search to find the position of leftmost 1 which is greater than index of current 1

ans=0
for i in range(len(arr)):
    for j in range(len(arr)):
        if i<j:
            
    
            if arr[i]+arr[j]>=arr[i]*arr[j]:
                print(arr[i],arr[j])
                print("*"*50)
                ans+=1
print(ans)
# only 1 will count
for ai in range(1,101):
    for aj in range(1,101):
        continue
        if ai+aj>=ai*aj:
            print(ai,aj)
            print("*"*50)
