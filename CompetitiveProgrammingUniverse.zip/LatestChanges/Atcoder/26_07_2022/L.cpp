#include "bits/stdc++.h"
using namespace std;
#define vi vector<int>
#define mem1(arr) memset(arr,-1,sizeof arr)
int n;
int a[3005];
int dp[3005][3005];

int calc(int l,int u,int m){
	if(l==u){
		return (1-m)*a[l];
	}
	int &ans = dp[l][u];
	if(ans!=-1)return ans;
	if(m){
		ans=min(calc(l+1,u,!m),calc(l,u-1,!m));
	}
	else{
		ans=max(a[l]+calc(l+1,u,!m),a[u]+calc(l,u-1,!m));
	}
	return ans;
}
int main(){
	mem1(dp);
	cin>>n;
	int s=0;
	for(int i=0;i<n;i++){
		cin>>a[i];
		s+=a[i];
	}
	int x= calc(0,n-1,0);
	int y=s-x;
	cout<<x-y<<endl;
	return 0;
}