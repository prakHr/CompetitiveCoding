#include "bits/stdc++.h"
using namespace std;
#define vi vector<int>
int dp[100005];
int main(){
	int n,k;
	cin>>n>>k;
	
	vi a(n);
	for(int &x:a){
		cin>>x;
	}
	dp[0]=0;
	for(int i=1;i<=k;i++){
		dp[i]=0;
		for(int x:a){
			if(i-x>=0 and dp[i-x]==0){
				dp[i]=1;
				break;
			}
		}
	}
	if(dp[k]==1){
		cout<<"First";
		
	}else{
		cout<<"Second";
	}
	return 0;
}