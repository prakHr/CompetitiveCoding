setVector=set()
def setRecursion(n):
    if n>10**10+1:
        return
    setVector.add(n)
    setRecursion(n*10+4)
    setRecursion(n*10+7)
setRecursion(4)
setRecursion(7)
allNums=list(setVector)
allNums.sort()
l,r=map(int,input().split())
ans=0# stores L0*(L0-1)+L1*(L1-(L0+1))+L2*(L2-(L1+1))
for num in allNums:
    if num>=r:
        ans+=num*(r-l+1)
        break
    elif num>=l:
        ans+=num*(num-l+1)
        l=num+1
print(ans)
