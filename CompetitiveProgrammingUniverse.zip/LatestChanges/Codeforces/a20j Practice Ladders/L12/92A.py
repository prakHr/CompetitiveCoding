n,m=list(map(int,input().split()))
x=n*(n+1)//2
remainder=m%x
solutionOfRemainder=((8*remainder+1)**.5-1)//2
y=solutionOfRemainder*(solutionOfRemainder+1)//2
ans=remainder-y
print(int(ans))
