n=int(input())
x=n*n
arr=list(range(1,x+1))
#print(arr)
l=0
r=x-1
while l<=r:
    ans=[arr[l],arr[r]]
    print(*ans)
    l+=1
    r-=1
