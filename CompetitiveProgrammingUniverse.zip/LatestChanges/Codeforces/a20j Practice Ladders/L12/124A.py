n,a,b=list(map(int,input().split()))
x=max(a+1,n-b)
ans = n-x+1
print(ans)
