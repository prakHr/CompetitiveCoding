n=int(input())
arr=list(map(int,input().split()))
ans=0
if n==1:
    if arr[0]==1:
        print(0)
    else:print(1)
else:
    
    for i in range(n):
        for j in range(i,n):
            
            newVector=arr.copy()
            #print(newVector)
            for k in range(n):
                if i<=k<=j:
                    newVector[k]=1-newVector[k]
            
            ans=max(ans,newVector.count(1))
    print(ans)
            
