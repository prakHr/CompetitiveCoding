'''
In this problem the sensible thing to do is to count the amount of times we are going to
add some index of this sequence; then
the maximal number gets assigned to the index that is added the most, and so on

'''
n,q=list(map(int,input().split()))
arr=list(map(int,input().split()))
b=[0]*(n+1)
c=[0]*n
for i in range(q):
    l,r=list(map(int,input().split()))
    b[l-1]+=1
    b[r]-=1

cummulativeSum=0
for i in range(n):
    cummulativeSum+=b[i]
    c[i]=cummulativeSum

c.sort()
arr.sort()
ans=0
for i in range(n):ans+=arr[i]*c[i]
print(ans)
