n=int(input())
arr=list(map(int,input().split()))
current=2
ans=0
if n<=2:
    print(n)
else:
    
    for i in range(2,n):
        a=arr[i-2]
        b=arr[i-1]
        c=a+b
        if arr[i]==c:
            current+=1
            #print("current->",current)
        else:
            ans=max(current,ans)
            current=2
    print(max(current,ans))
