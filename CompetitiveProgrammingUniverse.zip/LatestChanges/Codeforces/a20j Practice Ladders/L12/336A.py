x,y=list(map(int,input().split()))
if x>0:
    signx=1
else:
    signx=-1
if y>0:
    signy=1
else:
    signy=-1

val=abs(x)+abs(y)
x1,x2,y1,y2=val*signx,0,0,val*signy
if x1>x2:
    print(x2,y2,x1,y1)
else:
    print(x1,y1,x2,y2)
