n,k=list(map(int,input().split()))

arr=[]
for i in range(n,n-k+1-1,-1):
    arr.append(i)
#print(*arr)
for i in range(1,n-k+1):
    arr.append(i)
print(*arr)
