def form(x):
    if x>=n and str(x).count('4')==str(x).count('7'):
        a.append(x)
    if x<1e12+1:
        form(10*x+4)
        form(10*x+7)
n=int(input())
a=[]
form(0)
a.sort()
print(a[0])

