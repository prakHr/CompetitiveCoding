a=input()
b=input()
if len(a)!=len(b):
    print("NO")
elif a=='0'*len(a) and b!='0'*len(b):
    print("NO")
elif b=='0'*len(b) and a!='0'*len(a):
    print("NO")
else:print("YES")
