n,k=list(map(int,input().split()))
mat=[]
for i in range(n):
    res=[0]*n
    for j in range(n):
        if i==j:
            res[i]=k
    mat.append(res)
for i in range(n):
    print(*mat[i])
