	
#Obviously, suits are not change the answer. Look at all possible situations:

#[0 - 10] — zero ways.
#[11] — four ways using aces.
#[12 - 19] — four ways using cards from 2 to 9.
#[20] — 15 ways, they are described in statement.
#[21] — four ways using aces.
#[22 - 25] — zero ways.
