n=int(input())
arr=list(map(int,input().split()))
numFives=arr.count(5)
numZeros=arr.count(0)
# 5,5+5,5+5+5,20,25,30,35,40,45
if numZeros>0 and numFives>=9:
    while numFives%9!=0:
        numFives-=1
    string='5'*numFives+'0'*numZeros
    print(string)
elif numZeros>0:
    print(0)
else:
    print(-1)
