n=int(input())
arr=list(map(int,input().split()))
x=arr[-1]
s=set(arr)
for i in range(1,30000):
    if i not in s:
        print(i)
        break

