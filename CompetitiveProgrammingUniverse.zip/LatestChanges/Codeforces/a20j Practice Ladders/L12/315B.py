n,m=list(map(int,input().split()))
arr=list(map(int,input().split()))
b=0
ans=''
for _ in range(m):
    l=list(map(int,input().split()))
    if l[0]==3:
        ans+=str(arr[l[1]-1]+b)+'\n'
    elif l[0]==2:
        b+=l[1]
    elif l[0]==1:
        arr[l[1]-1]=l[2]-b

print(ans)
