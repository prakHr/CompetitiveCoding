n,m=list(map(int,input().split()))
arr=list(map(int,input().split()))
sortedArr=sorted(arr)
#print(sortedArr)
maxElement=100000
for i in range(m-n+1):
    a=sortedArr[i:i+n]
    #print(a)
    maxElement=min(maxElement,abs(a[0]-a[-1]))
print(maxElement)
