#include<iostream>
#include<vector>
#include<algorithm>
#include<map>
using namespace std;
int main ()
{
	struct {
		int x,y;
	}a[2100];
	int n;
	long long s=0;
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i].x>>a[i].y;
	for(int i=3;i<=n;i++)
	{
		for(int j=2;j<i;j++)
		{
			for(int k=1;k<j;k++)
			{
				if((a[j].y-a[i].y)*(a[k].x-a[j].x)!=(a[k].y-a[j].y)*(a[j].x-a[i].x))
					s++;
			}
		}
	}
	cout<<s<<endl;
}
	