n,m=list(map(int,input().split()))
if n<m:
    n,m=m,n
print(n-1,m)
