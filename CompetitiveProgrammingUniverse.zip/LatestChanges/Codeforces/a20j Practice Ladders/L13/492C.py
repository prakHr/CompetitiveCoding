n,limit,avg=list(map(int,input().split()))
arr=[]
s=0
avg*=n
for i in range(n):
    a,b=list(map(int,input().split()))
    s+=a
    arr.append((b,a))
arr.sort()
ans=0
i=0
while i<n and avg>s:
    x=min(limit-arr[i][1],avg-s)
    s+=x
    ans+=arr[i][0]*x
    i+=1
print(ans)
