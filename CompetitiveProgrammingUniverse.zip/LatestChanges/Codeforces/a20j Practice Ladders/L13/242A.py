x,y,a,b=list(map(int,input().split()))
arr=[]
for i in range(a,101):
    for j in range(b,101):
        if((i+j)<=(x+y)) and i>j and i<=x and j<=y:
            arr.append([i,j])
print(len(arr))
for i in range(len(arr)):
    print(*arr[i])
