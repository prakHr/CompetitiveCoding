mat=[list(input()) for i in range(8)]
#print(mat)
m1=list('BW'*4)
m2=list('WB'*4)
ok='YES'
for m in mat:
    if m!=m1 and m!=m2:
        ok='NO'
        break
print(ok)
