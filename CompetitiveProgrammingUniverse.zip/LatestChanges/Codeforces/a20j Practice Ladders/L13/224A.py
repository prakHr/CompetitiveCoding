s1,s2,s3=list(map(int,input().split()))
a=(s1*s2//s3)**.5
b=(s3*s2//s1)**.5
c=(s1*s3//s2)**.5
print(int(4*(a+b+c)))
