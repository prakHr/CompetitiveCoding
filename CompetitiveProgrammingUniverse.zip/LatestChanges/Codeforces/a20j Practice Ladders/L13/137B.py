n=int(input())
arr=list(map(int,input().split()))

print(n-len(set(range(1,n+1))&set(arr)))
