n,x=list(map(int,input().split()))
print((abs(sum(map(int, input().split()))) - 1) // x + 1)
