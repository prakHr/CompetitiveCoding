    
    
    
    
    #include <bits/stdc++.h>
    #include <cstdio>
    #include <cstring>
    #include <cmath>
    #include <cstring>
    #include <chrono>
    #include <complex>
    #define endl "\n"
    #define int long long int
    #define vi vector<int>
    #define vll vector<ll>
    #define vvi vector < vi >
    #define pii pair<int,int>
    #define pll pair<long long, long long>
    #define mod 1000000007
    #define inf 1000000000000000001;
    #define all(c) c.begin(),c.end()
    #define mp(x,y) make_pair(x,y)
    #define mem(a,val) memset(a,val,sizeof(a))
    #define eb emplace_back
    #define f first
    #define s second
    
    using namespace std;
    signed main()
    {

    #ifndef ONLINE_JUDGE
        freopen("input.txt","r",stdin);
        freopen("output.txt","w",stdout);
    #endif
ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int n,m,k,i,j,x,y;
    char c;
    cin>>n>>m>>k;
    int row[n],col[m],a[n][m];
    for (i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
        {
            cin>>a[i][j];
        }
    }
    for (i=0;i<n;i++)
    {
        row[i]=i;
    }
    for (i=0;i<m;i++)
    {
        col[i]=i;
    }
    for (i=0;i<k;i++)
    {
        cin>>c>>x>>y;
        x--;
        y--;
        if (c=='r')
        {
            swap(row[x],row[y]);
        }
        else if (c=='c')
        {
            swap(col[x],col[y]);
        }
        else
        {
            cout<<a[row[x]][col[y]]<<endl;
        }
    }

            
       
        
        return 0;
    }