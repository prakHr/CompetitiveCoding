m,n=list(map(int,input().split()))
q=0
for i in range(1,m):
    q+=(i/m)**n
print(m-q)    
