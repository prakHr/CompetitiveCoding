n,k,l,c,d,p,nl,np=list(map(int,input().split()))
A=k*l//nl
B=c*d
C=p//np
#print(A,B,C)
ans=min(min(A,B),C)
ans=ans//n
print(ans)
