n,x=map(int,input().split())
arr=sorted(list(map(int,input().split())))
sz=len(arr)
ans=0
while arr[(sz+1)//2-1]!=x:
    arr=sorted(arr+[x])
    sz=len(arr)
    ans+=1
    
print(ans)
