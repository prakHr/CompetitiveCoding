n,m,k=map(int,input().split())
table= [input().split() for i in range(n)]
row={str(i):i-1 for i in range(n+1)}
col={str(i):i-1 for i in range(m+1)}
ans=[]
for i in range(k):
    s,x,y=input().split()
    if s=='c':col[x],col[y]=col[y],col[x]
    elif s=='r':row[x],row[y]=row[y],row[x]
    else:ans.append(table[row[x]][col[y]])
print('\n'.join(ans))
