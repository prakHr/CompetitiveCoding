n,m=list(map(int,input().split()))
r=[input() for i in range(n)]
table=[max(i) for i in zip(*r)]
#print(table)
ans=sum(any(i[idx] == table[idx] for idx in range(m)) for i in r)
print(ans)
