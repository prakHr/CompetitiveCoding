n,m=list(map(int,input().split()))
arr=list(map(int,input().split()))
b=set()
for i in range(n-1,-1,-1):
    b.add(arr[i])
    arr[i]=len(b)
for i in range(m):
    print(arr[int(input())-1])
