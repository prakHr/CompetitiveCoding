n=int(input())
ans=1
x1=[]
y1=[]
for i in range(n):
    x,y=list(map(int,input().split()))
    x1.append({x})
    y1.append({y})
for i in range(n-1):
    for j in range(i+1,n):
        if x1[i]&x1[j] or y1[i]&y1[j]:
            x1[j]|=x1[i]
            y1[j]|=y1[i]
            ans+=1
            break
#print(x1);print(y1)
print(n-ans)
