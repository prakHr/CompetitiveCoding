from itertools import combinations_with_replacement
 
# Recursive function to return gcd of a and b
def gcd(a,b):
    if a == 0:
        return b
    return gcd(b % a, a)
 
# Function to return LCM of two numbers
def lcm(a,b):
    return (a / gcd(a,b))* b
 
n=int(input())
if n<3:
    print(n)
else:
    arr=[n,n-1,n-2,n-3]
    op1=lcm(lcm(n,n),n)
    ans=op1
    comb=combinations_with_replacement(arr,3)
    print(len(list(comb)))
    for i in list(comb):
        x=list(i)
        ans=max(ans,lcm(lcm(x[0],x[1]),x[2]))
        print(list(i))
        print(ans)
        print("____________")
    print(ans)
