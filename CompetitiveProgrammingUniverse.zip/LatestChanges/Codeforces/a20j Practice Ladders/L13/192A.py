p=set([(i*(i+1))//2 for i in range(1,45000)])
n=int(input())
ok='NO'
for i in p:
    if n-i in p:
        ok='YES'
        break
print(ok)
