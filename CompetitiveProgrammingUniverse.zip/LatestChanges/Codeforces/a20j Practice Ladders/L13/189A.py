n,a,b,c=list(map(int,input().split()))
# maximum of x+y+z
# st ax+by+cz=n
# z=(n-ax-by)/c
dp=[0]+[-1e9]*5000
for i in range(1,n+1):
    dp[i]=max(dp[i-a],dp[i-b],dp[i-c])+1
print(dp[n])
        
