n=int(input())
ans=[]
for i in range(n,-1,-1):
    arr=[t for t in range(n-i)]
    x=[' ']*(i)+arr+[n-i]
    x=x+arr[::-1]
    print(*x)
    if i==0:
        pass
    else:ans.append(x)
    #ans=' '*n+'0'*1+x+'0'*1
ans=ans[::-1]
for a in ans:
    print(*a)
