n,k=list(map(int,input().split()))
a=list(map(int,input().split()))
j=1
for i in range(k):
    l=[a[i]]
    while len(l)!=n:
        if j not in a:
            l.append(j)
        j+=1
    print(*l)
