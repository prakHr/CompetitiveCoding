n=int(input())
ans=0
while n%7!=0:
    ans+=1
    n=n-4
if(n<0):print(-1)
else:print('4'*ans+'7'*(n//7))
