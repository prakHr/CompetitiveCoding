n=int(input())
arr=list(map(int,input().split()))
arr.sort()
mn,mx=arr[0],arr[n-1]
print(mx-mn,end=' ')
if mn==mx:
    print(n*(n-1)//2)
else:
    print(arr.count(mn)*arr.count(mx))
