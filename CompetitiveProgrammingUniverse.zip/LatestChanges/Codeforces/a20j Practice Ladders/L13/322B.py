a,b,c=list(map(int,input().split()))
ans=0
for i in range(3):
    k=min(i,a,b,c)
    ans=max(ans,k+(a-k)//3+(b-k)//3+(c-k)//3)
print(ans)
