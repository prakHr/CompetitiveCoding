y,k,n=list(map(int,input().split()))
ans=[]
x=k-y%k
if x+y>n:
    print(-1)
while x+y<=n:
    print(x,end=' ')
    x+=k
#for x in range(1,n+1):
#    amt=x+y
#    if amt<=n and amt%k==0:
#        ans.append(x)
#if ans==[]:print(-1)
#else:print(*ans)
