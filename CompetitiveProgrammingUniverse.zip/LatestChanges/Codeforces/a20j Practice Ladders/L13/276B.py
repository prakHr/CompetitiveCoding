from collections import Counter
string=input()
freqDict=dict(Counter(list(string)))
OccurrenceOfOddKeys=0
for k,v in freqDict.items():
    if v%2==1:
        OccurrenceOfOddKeys+=1
if OccurrenceOfOddKeys%2==1 or OccurrenceOfOddKeys<=1:
    print('First')
else:print('Second')
