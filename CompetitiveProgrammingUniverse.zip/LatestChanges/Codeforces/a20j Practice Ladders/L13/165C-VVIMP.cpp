#include<bits/stdc++.h>
using namespace std;
#define FOR(i, j, k, in) for (int i=j ; i<k ; i+=in)
#define RFOR(i, j, k, in) for (int i=j ; i>=k ; i-=in)
#define REP(i, j) FOR(i, 0, j, 1)
map<int, int>m;
int main()
{
   int n,i,j,k, t,sum=0;
   long long ans=0;
   string s;
   cin>>k>>s;
 
   m[0]=1;
 
   n=s.size();
   REP(i,n){
   		if(s[i]=='1')sum++;
   		if(sum>=k)ans+=m[sum-k];
   		m[sum]++;
   		cout<<"sum:-"<<sum<<","<<"m[sum]:-"<<m[sum]<<endl;
   }
  cout<<ans<<endl;
 
}