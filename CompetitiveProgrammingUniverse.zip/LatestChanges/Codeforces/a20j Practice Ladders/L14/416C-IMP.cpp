#include <iostream>
#include <algorithm>
#include <vector>
#define fi first
#define se second
using namespace std;
bool cmp(pair<pair<int, int>, int>a,pair<pair<int, int>, int>b){
	if(a.fi.se>b.fi.se)
		return true;
	else if(a.fi.se==b.fi.se)
		return a.fi.fi<b.fi.fi;
	return false;
}
int main(){
	int n;
	scanf("%d",&n);
	pair<pair<int, int>, int>a[n];
	for(int i=0; i<n; i++){
		scanf("%d %d",&a[i].fi.fi,&a[i].fi.se);
		a[i].se=i;
	}
	cout<<"Before sorting (a,a+n,cmp);"<<endl;
	sort(a,a+n,cmp);
	for(int i=0; i<n; i++){
		cout<<"a[i].first.first<<a[i].first.second"<<endl;
		cout<<a[i].fi.fi<<" : "<<a[i].fi.se<<endl;
		
	}
	cout<<endl;
	int k;
	scanf("%d",&k);
	pair<int, int>b[k];
	for(int i=0; i<k; i++){
		scanf("%d",&b[i].fi);
		b[i].se=i;
	}
	cout<<"Before sorting (b,b+k);"<<endl;
	
	sort(b,b+k);
	for(int i=0; i<k; i++){
		cout<<"b[i].first"<<endl;
		cout<<b[i].fi<<endl;
	}
	cout<<endl;
	int cst=0,occ[k]={0};
	vector<pair<int, int>>ans;
	for(int i=0; i<n; i++)
		for(int j=0; j<k; j++){
			if(occ[j])
				continue;
			if(a[i].fi.fi<=b[j].fi){
		 		occ[j]=1;
		 		//+1 for index
				ans.push_back({a[i].se+1,b[j].se+1});
				cst+=a[i].fi.se;
				break;
			}
		}
	printf("%d %d\n", (int)ans.size(),cst);
	for(auto [x,y]:ans)
		printf("%d %d\n", x,y);
}