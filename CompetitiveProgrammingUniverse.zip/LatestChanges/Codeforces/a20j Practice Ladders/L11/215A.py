n=int(input())
arr1=list(map(int,input().split()))
m=int(input())
arr2=list(map(int,input().split()))
maxVal=0
for i in range(n):
    for j in range(m):
        x=arr2[j]/arr1[i]
        if x*x==int(x*x):
            maxVal=max(maxVal,x)
#print(maxVal)
ans=0
for i in range(n):
    for j in range(m):
        x=arr2[j]/arr1[i]
        if maxVal==x:
            ans+=1
print(ans)
