n,k=list(map(int,input().split()))
arr=list(map(int,input().split()))


ans=1
x=minTotal=sum(arr[:k])

for i in range(k,n):
    x+=arr[i]
    x-=arr[i-k]
    
    if minTotal>x:
        minTotal=x
        ans=i-k+1+1
    
print(ans)
