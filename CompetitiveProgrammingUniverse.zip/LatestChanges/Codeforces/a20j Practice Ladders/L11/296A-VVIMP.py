from collections import Counter
n=int(input())
arr=list(map(int,input().split()))
#n<2*count or n+1>=2*count
print("YES" if all([arr.count(i)*2-1<=n for i in arr]) else "NO")
