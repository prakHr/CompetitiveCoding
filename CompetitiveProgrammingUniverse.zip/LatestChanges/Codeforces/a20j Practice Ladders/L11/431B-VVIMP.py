from itertools import permutations

G = [list(map(int,input().split())) for i in range(5)]
function = lambda i,j:G[i][j]+G[j][i]
print(max(2*(function(a,b)+function(b,c))+function(c,d)+function(d,e) for a,b,c,d,e in permutations(range(5))))
