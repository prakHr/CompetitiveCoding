ok=True
a,b,c=list(map(int,input().split()))
for i in range(10):
    x=int(str(a)+str(i))
    zero='0'*(c-1)
    if x%b==0:
        print(str(x)+zero)
        ok=False
        break
if ok==True:
    print(-1)
