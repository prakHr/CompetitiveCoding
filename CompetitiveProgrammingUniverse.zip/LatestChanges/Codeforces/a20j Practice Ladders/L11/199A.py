arr=[0,0,int(input())]
print(*arr)
