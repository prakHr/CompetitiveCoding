n=int(input())
arr=list(map(int,input().split()))
sortedArr=sorted(arr)
ans,j=0,1
for i in range(n):
    ans+=abs(sortedArr[i]-j)
    j+=1
print(ans)
