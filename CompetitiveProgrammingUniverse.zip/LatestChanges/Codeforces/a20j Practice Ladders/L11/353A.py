n=int(input())
s1,s2=0,0
different=0
for i in range(n):
    half1,half2=list(map(int,input().split()))
    if half1%2==1 and half2%2==0:
        different=1
    if half1%2==0 and half2%2==1:
        different=1
    
    s1+=half1
    s2+=half2
if s1%2==0 and s2%2==0:
    print(0)
elif (s1%2==1 and s2%2==0) or (s1%2==0 and s2%2==1):
    print(-1)
else:
    #both are odd
    if different==1:
        print(1)
    else:print(-1)
