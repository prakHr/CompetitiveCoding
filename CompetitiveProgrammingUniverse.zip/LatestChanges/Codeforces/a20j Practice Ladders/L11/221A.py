n=int(input())
arr=[n]+list(range(1,n))
print(*arr)
