string=input()
n=len(string)
a=string.replace("144","+++")
b=a.replace("14","++")
c=b.replace("1","+")
if c=="+"*n:
    print("YES")
else:print("NO")
