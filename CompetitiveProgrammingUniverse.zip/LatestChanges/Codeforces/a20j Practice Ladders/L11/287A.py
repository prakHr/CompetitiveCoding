grid=[list(input()) for i in range(4)]
#print(grid)
ok='NO'
for i in range(3):
    for j in range(3):
        ans=grid[i][j]+grid[i+1][j]+grid[i][j+1]+grid[i+1][j+1]
        #print(ans)
        
        if ans.count('#')>=3 or ans.count('.')>=3:
            ok='YES'
            break
print(ok)
