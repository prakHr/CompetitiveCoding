print(*[10**5+i for i in range(int(input()))])
