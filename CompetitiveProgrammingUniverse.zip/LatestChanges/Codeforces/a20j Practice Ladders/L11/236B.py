a,b,c=list(map(int,input().split()))

RANGE=a*b*c+1
MOD=1073741824

divisors=[2]*(RANGE)
divisors[0]=0
divisors[1]=1
for i in range(2,RANGE):
    for j in range(2*i,RANGE,i):
        divisors[j]+=1
            
ans=0
for i in range(1,a+1):
    for j in range(1,b+1):
        for k in range(1,c+1):
            ans+=divisors[i*j*k]
            ans%=MOD
print(ans)
