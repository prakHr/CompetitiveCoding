f=open("input.txt",'r');g=open("output.txt",'w')
n,m=map(int,f.readline().split())
#n,m=list(map(int,input().split()))
x=min(n,m)
if x==m:
    ans='BG'*m
else:ans='GB'*n
if n>m:
    ans+='B'*(n-m)
else:ans+='G'*(m-n)
g.write(ans)
