RANGE=10000
values=[]
primes=[1]*(RANGE)
primes[0]=0
primes[1]=0
for i in range(RANGE):
    if primes[i]==1:
        values.append(i)
        for j in range(2*i,RANGE,i):
            primes[j]=0
#print(len(values))
#print(values)

n,m=list(map(int,input().split()))

idx=values.index(n)
nextElement=values[idx+1]
if nextElement==m:
    print("YES")
else:print("NO")
