n=input()
arr=list(n)
try:
    idx=arr.index('0')
    n=n[:idx]+n[idx+1:]
    print(n)
except:
    print(n[1:])

