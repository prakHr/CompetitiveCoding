n=int(input())
maxx,minn=-1,1e10
arr=[]
for i in range(n):
    l,r=list(map(int,input().split()))
    maxx=max(maxx,r)
    minn=min(minn,l)
    arr.append([l,r])
try:
    print(1+arr.index([minn,maxx]))
except:
    print(-1)
