n,m=list(map(int,input().split()))
x=max(n,m)+1
ans=0
for a in range(0,x):
    for b in range(0,x):
        if a*a+b==n and a+b*b==m:
            ans+=1
print(ans)
