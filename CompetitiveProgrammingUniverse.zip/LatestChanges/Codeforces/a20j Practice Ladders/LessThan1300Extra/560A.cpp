#include <bits/stdc++.h>
using namespace std;
 
int H,M;
 
int main(){
	
	long n,a[1000],i,c=0;
	cin>>n;
	for(i=0;i<n;i++)cin>>a[i];
	sort(a,a+n);
	if(a[0]==1)cout<<-1;
	else cout<<1;
	return 0;
}