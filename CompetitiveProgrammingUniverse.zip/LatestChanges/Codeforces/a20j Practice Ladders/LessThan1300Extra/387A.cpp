#include <bits/stdc++.h>
using namespace std;
int main(){
  int sh, sm;
  scanf ("%d:%d", &sh, &sm);
  int th, tm;
  scanf ("%d:%d", &th, &tm);
  int res = sh * 60 + sm - th * 60 - tm;
  res = res < 0 ? 24 * 60 + res : res;
  printf ("%02d:%02d", res / 60, res % 60);
  return 0;
}