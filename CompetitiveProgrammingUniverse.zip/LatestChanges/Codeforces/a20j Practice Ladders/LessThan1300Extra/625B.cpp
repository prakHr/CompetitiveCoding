#include <bits/stdc++.h>
using namespace std;
int main()
{
    string a,b;
    int pos=0,ans=0;
    cin>>a>>b;
    while(pos=a.find(b,pos),pos!=-1)
    {
        a[pos]='#';
        pos+=b.size();
        ans++;
    }
    printf("%d\n",ans);
    return 0;
}
 