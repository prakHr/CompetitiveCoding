#include <bits/stdc++.h>
using namespace std;
 
int H,M;
 
int main(){
	
	scanf("%d:%d",&H,&M);
	for( ; ; ){
		
		M++;
		if(M == 60) H++,M=0;
		if(H == 24) H=0;
		if(H%10 == M/10 && H/10 == M%10) break;
		
	}
	
	printf("%.2d:%.2d\n",H,M);
	
	return 0;
}