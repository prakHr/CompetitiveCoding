#include<cstdio>
#include<algorithm>
using namespace std;
int main(){
   int n,m;
  scanf("%d%d",&n,&m);
  int a1;
   int neg=0; int pos=0;
  for( int i=0;i<n;i++){
    scanf("%d",&a1);
    if(a1==1){pos++;}
    else neg++;
  }
  int a,b,c;
  c=min(neg,pos)*2;
  while(m--){
     scanf("%d%d",&a,&b);
    printf((b-a)%2==1 && b-a<c ?"1\n":"0\n");
     
  }
}